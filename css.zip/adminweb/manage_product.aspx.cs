using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Net;
    public partial class manage_product : System.Web.UI.Page 
{
string Location2 = HttpContext.Current.Server.MapPath("..")+"//allimages//product//";


int width=200;


int height=200;


nitin nn = new nitin();
string table_name_7="";
string column_name_7="" ;

        protected void Page_Load(object sender, EventArgs e) {
if (!Page.IsPostBack) {
loaddata_MAIN_ADMIN();
nn.DROPDOWNBIND(dropdown_category,"select * from "+table_name_7+"",""+column_name_7+"","id");

 }
        }
   void loaddata_MAIN_ADMIN()
    {
 string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);


        SqlDataAdapter da = new SqlDataAdapter("select * from product order by id desc", sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);


        CollectionPager1.DataSource = ds.Tables[0].DefaultView;
        CollectionPager1.BindToControl = GRD1_MAIN_ADMIN;
        GRD1_MAIN_ADMIN.DataSource = CollectionPager1.DataSourcePaged;
    }
    protected void fixgrid_GRD1_MAIN_ADMIN(object sender, EventArgs e)
    {
        if (GRD1_MAIN_ADMIN.Rows.Count > 0)
        {
            //This replaces <td> with <th> and adds the scope attribute
            GRD1_MAIN_ADMIN.UseAccessibleHeader = true;

            //This will add the <thead> and <tbody> elements
            GRD1_MAIN_ADMIN.HeaderRow.TableSection = TableRowSection.TableHeader;


        }
    }
    protected void up_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("up", id, pos, "product");

        loaddata_MAIN_ADMIN();

    }

    protected void down_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("down", id, pos, "product");

        loaddata_MAIN_ADMIN();
    }


    protected void top_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.newtoppos(id, pos, "product");

        loaddata_MAIN_ADMIN();
    }


    protected void bot_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.bottompos(id, pos, "product");

        loaddata_MAIN_ADMIN();
    }

    protected void delete_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton delete = (LinkButton)sender;

        nitin mk = new nitin();

        mk.DeleteData("product", "id", delete.CommandArgument.ToString());

        loaddata_MAIN_ADMIN();

    }
    protected void delmulti_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();

        foreach (GridViewRow di in GRD1_MAIN_ADMIN.Rows)
        {
            HtmlInputCheckBox chk = (HtmlInputCheckBox)di.FindControl("check");
            HiddenField id = (HiddenField)di.FindControl("HiddenField1");

            if (chk.Checked)
            {
                nk.DeleteALL("delete product where id='" + id.Value.ToString() + "'");
            }

        }
        loaddata_MAIN_ADMIN();
    }

    protected void dellall_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();


        nk.DeleteALL("delete product");


        loaddata_MAIN_ADMIN();
    }
    protected void edit_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton ed = (LinkButton)sender;
        string ID = ed.CommandArgument.ToString();

        getdetails_MAIN_ADMIN(ID);

    }
    void getdetails_MAIN_ADMIN(string ID)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);

        try
        {
            string sql3 = "select * from product where id='" + ID + "'";
            SqlCommand sqlComm3 = new SqlCommand(sql3, sqlConn);
            sqlConn.Open();

            SqlDataReader dr3 = sqlComm3.ExecuteReader();
            if (dr3.Read())
            {
                update_MAIN_ADMIN.ToolTip = dr3[0].ToString();
                update_MAIN_ADMIN.Visible = true;
                insert_MAIN_ADMIN.Visible = false;
 txt_name_title.Text= dr3["title"].ToString();
txt_name_sub_title.Text= dr3["sub_title"].ToString();
txt_name_product_id.Text= dr3["product_id"].ToString();
txt_name_text.Text= dr3["text"].ToString();
multi_txt_name_sub_text.Text= dr3["sub_text"].ToString();
 txt_name_price.Text= dr3["price"].ToString();
txt_name_discounted_price.Text= dr3["discounted_price"].ToString();
                }

            dr3.Close();
            sqlConn.Close();
        }
        finally
        {

            sqlConn.Close();
        }

    }
   protected void status(object sender, EventArgs e)
    {

        LinkButton ed = (LinkButton)sender;
        string id = ed.CommandArgument.ToString();
        string status = ed.ToolTip.ToString();


        nitin kj = new nitin();

        if (status == "False")
        {
           
            kj.UpdateData("update product set [status]='true' where id='" + id + "'");
        }
        else
        {
            kj.UpdateData("update product set [status]='false' where id='" + id + "'");
        }



      


        loaddata_MAIN_ADMIN();

    }

 protected void insert_Click(object sender, EventArgs e) {
 string String_FileUpload_images="";            Directory.CreateDirectory(Location2);
            if (FileUpload_images.HasFile)
            {
                FileUpload_images.SaveAs(Location2  + FileUpload_images.FileName.ToString());

                String_FileUpload_images = nn.Smallthumb(Location2, FileUpload_images.FileName, width, height);

                string filedel = Location2 + FileUpload_images.FileName.ToString();
                File.Delete(filedel);
 nn.InsertData("insert into product (id,title,sub_title,product_id,text,sub_text,category,price,discounted_price,images,dateadded,pos,status)values('"+nn.getid("product")+"','"+txt_name_title.Text+"','"+txt_name_sub_title.Text+"','"+txt_name_product_id.Text+"','"+txt_name_text.Text+"','"+multi_txt_name_sub_text.Text+"','"+dropdown_category.SelectedValue.ToString()+"','"+txt_name_price.Text+"','"+txt_name_discounted_price.Text+"','"+String_FileUpload_images+"','"+DateTime.Now.ToString()+"','"+nn.getid("product")+"','true')");            }
            else
            {
 nn.InsertData("insert into product (id,title,sub_title,product_id,text,sub_text,category,price,discounted_price,images,dateadded,pos,status)values('"+nn.getid("product")+"','"+txt_name_title.Text+"','"+txt_name_sub_title.Text+"','"+txt_name_product_id.Text+"','"+txt_name_text.Text+"','"+multi_txt_name_sub_text.Text+"','"+dropdown_category.SelectedValue.ToString()+"','"+txt_name_price.Text+"','"+txt_name_discounted_price.Text+"','"+String_FileUpload_images+"','"+DateTime.Now.ToString()+"','"+nn.getid("product")+"','true')");            }

  loaddata_MAIN_ADMIN();
   }
protected void update_Click(object sender, EventArgs e)
 {
 string id = update_MAIN_ADMIN.ToolTip.ToString();
 string String_FileUpload_images="";            Directory.CreateDirectory(Location2);
            if (FileUpload_images.HasFile)
            {
                FileUpload_images.SaveAs(Location2  + FileUpload_images.FileName.ToString());

                String_FileUpload_images = nn.Smallthumb(Location2, FileUpload_images.FileName, width, height);

                string filedel = Location2 + FileUpload_images.FileName.ToString();
                File.Delete(filedel);
 string UPDQRY = "update product set [title]='" + txt_name_title.Text + "',[sub_title]='" + txt_name_sub_title.Text + "',[product_id]='" + txt_name_product_id.Text + "',[text]='" + txt_name_text.Text + "',[sub_text]='" + multi_txt_name_sub_text.Text + "',[price]='" + txt_name_price.Text + "',[discounted_price]='" + txt_name_discounted_price.Text + "',[images]='" + String_FileUpload_images + "' where id='" + id + "'";
nn.UpdateData(UPDQRY);            }
            else
            {
 string UPDQRY = "update product set [title]='" + txt_name_title.Text + "',[sub_title]='" + txt_name_sub_title.Text + "',[product_id]='" + txt_name_product_id.Text + "',[text]='" + txt_name_text.Text + "',[sub_text]='" + multi_txt_name_sub_text.Text + "',[price]='" + txt_name_price.Text + "',[discounted_price]='" + txt_name_discounted_price.Text + "' where id='" + id + "'";
nn.UpdateData(UPDQRY);            }

loaddata_MAIN_ADMIN();
}
    }
