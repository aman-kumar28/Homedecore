﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class walladmin_adjustimg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
      


        if (!Page.IsPostBack)
        {
            adjust();
           // writeid();
            
            

        }
    }
    void adjust()
    {
        string id = Request.QueryString["id"].ToString();

        

        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;

        SqlConnection sqlConn = new SqlConnection(connectionString);

        string sql3 = "select * from photos where adj='0' and album_id=@adj";

        SqlCommand sqlComm3 = new SqlCommand(sql3, sqlConn);


        sqlComm3.Parameters.Add("@adj", System.Data.SqlDbType.VarChar);
        sqlComm3.Parameters["@adj"].Value = id.ToString();

        sqlConn.Open();

        SqlDataReader dr3 = sqlComm3.ExecuteReader();
        Repeater1.DataSource = dr3;
        Repeater1.DataBind();
        dr3.Close();
        sqlConn.Close();



    }
    protected void Button1_Click(object sender, EventArgs e)
    {


        foreach (RepeaterItem item in Repeater1.Items)
        {

            // find control of checkbox
            CheckBox chk = (CheckBox)item.FindControl("CheckBox1");


            


            TextBox title = (TextBox)item.FindControl("TextBox2");
            TextBox artist = (TextBox)item.FindControl("TextBox3");
            TextBox copyright = (TextBox)item.FindControl("TextBox4");
            TextBox tag = (TextBox)item.FindControl("TextBox5");

            
            

            

            if (chk.Checked == true)
            {
             


                string nes = chk.ToolTip.ToString();

                mukesh(nes,title.Text.ToString(),artist.Text.ToString(),copyright.Text.ToString(),tag.Text.ToString());


            }
        }
        string id = Request.QueryString["id"].ToString();
     
        Response.Redirect("editphotoalbum.aspx?id=" + id+"&num=5");

    }

    void mukesh(string id, string title, string artist, string copy, string tag)
    {

        string id2 = Request.QueryString["id"].ToString();
        //  Response.Write(n);

        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);




        string sql2 = "update photos set Title=@mp3name, Artist=@about ,Copyrightnotice=@cpy ,agecat=@cat, hits=@hits , adj=@ad , tag=@tag, artid=@artid  where id=@id";


        SqlCommand sqlComm = new SqlCommand(sql2, sqlConn);



        sqlComm.Parameters.Add("@mp3name", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@mp3name"].Value = title;

        sqlComm.Parameters.Add("@about", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@about"].Value = artist;

        sqlComm.Parameters.Add("@cpy", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@cpy"].Value = copy;

        sqlComm.Parameters.Add("@hits", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@hits"].Value = "0";

        sqlComm.Parameters.Add("@cat", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@cat"].Value = "0";

        sqlComm.Parameters.Add("@tag", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@tag"].Value = tag;

        string d = System.Guid.NewGuid().ToString().Substring(0, 3);

        sqlComm.Parameters.Add("@artid", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@artid"].Value = "ART-" + id.ToString().ToUpper() + d.ToString().ToUpper();


        sqlComm.Parameters.Add("@id", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@id"].Value = id.ToString();


        sqlComm.Parameters.Add("@ad", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@ad"].Value = "1";




        sqlConn.Open();
        sqlComm.ExecuteNonQuery();
        sqlConn.Close();



    }

    void writeid()
    {

        string id2 = Request.QueryString["id"].ToString();
        //  Response.Write(n);

        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);


        string sql2 = "update photos set album_id=@mp3name where adj=@id";


        SqlCommand sqlComm = new SqlCommand(sql2, sqlConn);

        sqlComm.Parameters.Add("@mp3name", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@mp3name"].Value = id2.ToString();

        sqlComm.Parameters.Add("@id", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@id"].Value = "0";

        sqlConn.Open();
        sqlComm.ExecuteNonQuery();
        sqlConn.Close();

        

    }

    
}
