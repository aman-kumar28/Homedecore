﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Net;


public partial class MasterPage : System.Web.UI.MasterPage
{
    public static string domain = "http://localhost:1382/simpled/adminweb/dashboard.aspx";
    SqlConnection connectionString = new SqlConnection(ConfigurationManager.ConnectionStrings["mvcconnection"].ConnectionString.ToString());
    string Location2 = HttpContext.Current.Server.MapPath(" ");
    nitin nn = new nitin();
    Int32 val;
    string links = "";
    int i = 1;

    protected void Page_Load(object sender, EventArgs e)
    {
        string url = Request.Url.ToString();
        string last = url.Substring(url.LastIndexOf('/') + 1);
        string[] files = Directory.GetFiles(Location2, "*.aspx");
        foreach (var item in files)
        {
            if (i == 1)
            {
                //links = links + "<div class=\"templatemo-content-widget white-bg\" style=\"visibility:hidden; display:none;\"><div class=\"media\"><div class=\"media-left\"><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\"><img class=\"media-object img-circle\" src=\"images/sunset.png\" alt=\"Sunset\"></a></div><div class=\"media-body\"><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\" style=\"color:#f17a54;\"><h2 class=\"media-heading text-uppercase\">" + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + "</h2></a></div></div></div>";


                links = links + "<li><a href=#layouts class=\"layouts\">" + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "").Replace("Chenge", "Change") + "</a><ul><li><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\"> " + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "").Replace("Chenge", "Change") + "</a></li></ul></li>";
                //links = links + "<li><a class=\"layouts\" href=\"" + "#layouts" + "\"> " + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + " </a><ul><li><a href=\"" + Request.Url.ToString().Replace(last, "") + "\">" + item.ToString().Replace(Location2, "") + "\"> " + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + " </a></li></ul> </li>";
                i++;

            }
            else
            {
                if (i % 2 == 0)
                {
                    i++;
                    links = links + "<li><a class=\"layouts\" href=\"" + "#layouts" + "\"> " + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + " </a><ul><li><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\"> " + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "").Replace("Chenge", "Change") + " </a></li></ul> </li>";
                    //    links = links + "<div class=\"templatemo-content-widget orange-bg\" style=\"padding:10px;\"><div class=\"media\"><div class=\"media-left\"><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\"><img class=\"media-object img-circle\" src=\"images/sunset.png\" alt=\"Sunset\"></a></div><div class=\"media-body\"><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\" style=\"color:white;\"><h2 class=\"media-heading text-uppercase\">" + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + "</h2></a></div></div></div>";
                }
                else
                {
                    if (i % 2 == 0)
                    {
                        i++;


                        links = links + "<li><a class=\"layouts\" href=\"" + "#layouts" + "\"> " + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + " </a><ul><li><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\"> " + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + " </a></li></ul> </li>";

                        //links = links + "<div class=\"templatemo-content-widget orange-bg\" style=\"padding:10px;\"><div class=\"media\"><div class=\"media-left\"><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\"><img class=\"media-object img-circle\" src=\"images/sunset.png\" alt=\"Sunset\"></a></div><div class=\"media-body\"><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\" style=\"color:white;\"><h2 class=\"media-heading text-uppercase\">" + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + "</h2></a></div></div></div>";
                    }
                    else
                    {

                        links = links + "<li><a class=\"layouts\" href=\"" + "#layouts" + "\"> " + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + " </a><ul><li><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\"> " + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + " </a></li></ul> </li>";
                        //links = links + "<div class=\"templatemo-content-widget white-bg\" style=\"padding:10px;\"><div class=\"media\"><div class=\"media-left\"><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\"><img class=\"media-object img-circle\" src=\"images/sunset.png\" alt=\"Sunset\"></a></div><div class=\"media-body\"><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\" style=\"color:#13895F;\"><h2 class=\"media-heading text-uppercase\">" + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + "</h2></a></div></div></div>";
                        i++;
                    }
                }
                //links = links + " <li><a href=\"" + Request.Url.ToString().Replace(last, "") + "" + item.ToString().Replace(Location2, "") + "\">" + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "") + "</a> </li>";


            }
            //lit_links.Text = links.Replace("autogen.aspx", "").Replace("autogen", "").Replace("adj.aspx", "").Replace("adj", "").Replace("ustimg.aspx", "").Replace("ustimg", "").Replace("deleteimg.aspx", "").Replace("deleteimg", "").Replace("editpho.aspx", "").Replace("editpho", "").Replace("toalbum.aspx", "").Replace("toalbum", "").Replace("sql_tool.aspx", "").Replace("sql tool", "");
        }
    }
    public string limit(string input)
    {

        string newstr = "";
        int l = input.Length;
        if (l > 10)
        {
            newstr = input.Substring(0, 20) + "...";

        }

        else
        {
            newstr = input;
        }
        return newstr;

    }
}