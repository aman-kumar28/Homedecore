using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Net;
    public partial class manage_application_form : System.Web.UI.Page 
{
string Location2 = HttpContext.Current.Server.MapPath(" ")+"//temp//";


int width=200;


int height=200;


nitin nn = new nitin();
string table_name_2="";
string column_name_2="" ;
string table_name_8="";
string column_name_8="" ;
string table_name_10="";
string column_name_10="" ;
string table_name_11="";
string column_name_11="" ;
string table_name_12="";
string column_name_12="" ;
string table_name_14="";
string column_name_14="" ;

        protected void Page_Load(object sender, EventArgs e) {
if (!Page.IsPostBack) {
loaddata_MAIN_ADMIN();
nn.DROPDOWNBIND(dropdown_applied_for,"select * from "+table_name_2+"",""+column_name_2+"","id");
nn.DROPDOWNBIND(dropdown_category,"select * from "+table_name_8+"",""+column_name_8+"","id");
nn.DROPDOWNBIND(dropdown_blod_group,"select * from "+table_name_10+"",""+column_name_10+"","id");
nn.DROPDOWNBIND(dropdown_physicaly_handicapped,"select * from "+table_name_11+"",""+column_name_11+"","id");
nn.DROPDOWNBIND(dropdown_eye_sight,"select * from "+table_name_12+"",""+column_name_12+"","id");
nn.DROPDOWNBIND(dropdown_gender,"select * from "+table_name_14+"",""+column_name_14+"","id");

 }
        }
   void loaddata_MAIN_ADMIN()
    {
 string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);


        SqlDataAdapter da = new SqlDataAdapter("select * from application_form order by id desc", sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);


        CollectionPager1.DataSource = ds.Tables[0].DefaultView;
        CollectionPager1.BindToControl = GRD1_MAIN_ADMIN;
        GRD1_MAIN_ADMIN.DataSource = CollectionPager1.DataSourcePaged;
    }
    protected void fixgrid_GRD1_MAIN_ADMIN(object sender, EventArgs e)
    {
        if (GRD1_MAIN_ADMIN.Rows.Count > 0)
        {
            //This replaces <td> with <th> and adds the scope attribute
            GRD1_MAIN_ADMIN.UseAccessibleHeader = true;

            //This will add the <thead> and <tbody> elements
            GRD1_MAIN_ADMIN.HeaderRow.TableSection = TableRowSection.TableHeader;


        }
    }
    protected void up_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("up", id, pos, "application_form");

        loaddata_MAIN_ADMIN();

    }

    protected void down_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("down", id, pos, "application_form");

        loaddata_MAIN_ADMIN();
    }


    protected void top_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.newtoppos(id, pos, "application_form");

        loaddata_MAIN_ADMIN();
    }


    protected void bot_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.bottompos(id, pos, "application_form");

        loaddata_MAIN_ADMIN();
    }

    protected void delete_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton delete = (LinkButton)sender;

        nitin mk = new nitin();

        mk.DeleteData("application_form", "id", delete.CommandArgument.ToString());

        loaddata_MAIN_ADMIN();

    }
    protected void delmulti_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();

        foreach (GridViewRow di in GRD1_MAIN_ADMIN.Rows)
        {
            HtmlInputCheckBox chk = (HtmlInputCheckBox)di.FindControl("check");
            HiddenField id = (HiddenField)di.FindControl("HiddenField1");

            if (chk.Checked)
            {
                nk.DeleteALL("delete application_form where id='" + id.Value.ToString() + "'");
            }

        }
        loaddata_MAIN_ADMIN();
    }

    protected void dellall_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();


        nk.DeleteALL("delete application_form");


        loaddata_MAIN_ADMIN();
    }
    protected void edit_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton ed = (LinkButton)sender;
        string ID = ed.CommandArgument.ToString();

        getdetails_MAIN_ADMIN(ID);

    }
    void getdetails_MAIN_ADMIN(string ID)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);

        try
        {
            string sql3 = "select * from application_form where id='" + ID + "'";
            SqlCommand sqlComm3 = new SqlCommand(sql3, sqlConn);
            sqlConn.Open();

            SqlDataReader dr3 = sqlComm3.ExecuteReader();
            if (dr3.Read())
            {
                update_MAIN_ADMIN.ToolTip = dr3[0].ToString();
                update_MAIN_ADMIN.Visible = true;
                insert_MAIN_ADMIN.Visible = false;
  txt_name_exam_city.Text= dr3["exam_city"].ToString();
txt_name_name.Text= dr3["name"].ToString();
txt_name_father_name.Text= dr3["father_name"].ToString();
txt_name_mother_name.Text= dr3["mother_name"].ToString();
txt_name_dob.Text= dr3["dob"].ToString();
 txt_name_mobile_number.Text= dr3["mobile_number"].ToString();
   txt_name_email.Text= dr3["email"].ToString();
 multi_txt_name_address.Text= dr3["address"].ToString();
txt_name_locality.Text= dr3["locality"].ToString();
txt_name_city.Text= dr3["city"].ToString();
txt_name_pin_code.Text= dr3["pin_code"].ToString();
txt_name_state.Text= dr3["state"].ToString();
txt_name_district.Text= dr3["district"].ToString();
txt_name_highschoolpassing_year.Text= dr3["highschoolpassing_year"].ToString();
txt_name_highschoolpercentage.Text= dr3["highschoolpercentage"].ToString();
txt_name_intermediatepassing_year.Text= dr3["intermediatepassing_year"].ToString();
txt_name_intermediatepercentage.Text= dr3["intermediatepercentage"].ToString();
txt_name_other_degree.Text= dr3["other_degree"].ToString();
 multi_txt_name_message.Text= dr3["message"].ToString();
               }

            dr3.Close();
            sqlConn.Close();
        }
        finally
        {

            sqlConn.Close();
        }

    }
   protected void status(object sender, EventArgs e)
    {

        LinkButton ed = (LinkButton)sender;
        string id = ed.CommandArgument.ToString();
        string status = ed.ToolTip.ToString();


        nitin kj = new nitin();

        if (status == "False")
        {
           
            kj.UpdateData("update application_form set [status]='true' where id='" + id + "'");
        }
        else
        {
            kj.UpdateData("update application_form set [status]='false' where id='" + id + "'");
        }



      


        loaddata_MAIN_ADMIN();

    }

 protected void insert_Click(object sender, EventArgs e) {
 string String_FileUpload_upload_photo="";            Directory.CreateDirectory(Location2);
            if (FileUpload_upload_photo.HasFile)
            {
                FileUpload_upload_photo.SaveAs(Location2  + FileUpload_upload_photo.FileName.ToString());

                String_FileUpload_upload_photo = nn.Smallthumb(Location2, FileUpload_upload_photo.FileName, width, height);

                string filedel = Location2 + FileUpload_upload_photo.FileName.ToString();
                File.Delete(filedel);
 nn.InsertData("insert into application_form (id,applied_for,exam_city,name,father_name,mother_name,dob,category,mobile_number,blod_group,physicaly_handicapped,eye_sight,email,gender,address,locality,city,pin_code,state,district,highschoolpassing_year,highschoolpercentage,intermediatepassing_year,intermediatepercentage,other_degree,upload_photo,message,dateadded,pos,status)values('"+nn.getid("application_form")+"','"+dropdown_applied_for.SelectedValue.ToString()+"','"+txt_name_exam_city.Text+"','"+txt_name_name.Text+"','"+txt_name_father_name.Text+"','"+txt_name_mother_name.Text+"','"+txt_name_dob.Text+"','"+dropdown_category.SelectedValue.ToString()+"','"+txt_name_mobile_number.Text+"','"+dropdown_blod_group.SelectedValue.ToString()+"','"+dropdown_physicaly_handicapped.SelectedValue.ToString()+"','"+dropdown_eye_sight.SelectedValue.ToString()+"','"+txt_name_email.Text+"','"+dropdown_gender.SelectedValue.ToString()+"','"+multi_txt_name_address.Text+"','"+txt_name_locality.Text+"','"+txt_name_city.Text+"','"+txt_name_pin_code.Text+"','"+txt_name_state.Text+"','"+txt_name_district.Text+"','"+txt_name_highschoolpassing_year.Text+"','"+txt_name_highschoolpercentage.Text+"','"+txt_name_intermediatepassing_year.Text+"','"+txt_name_intermediatepercentage.Text+"','"+txt_name_other_degree.Text+"','"+String_FileUpload_upload_photo+"','"+multi_txt_name_message.Text+"','"+DateTime.Now.ToString()+"','"+nn.getid("application_form")+"','true')");            }
            else
            {
 nn.InsertData("insert into application_form (id,applied_for,exam_city,name,father_name,mother_name,dob,category,mobile_number,blod_group,physicaly_handicapped,eye_sight,email,gender,address,locality,city,pin_code,state,district,highschoolpassing_year,highschoolpercentage,intermediatepassing_year,intermediatepercentage,other_degree,upload_photo,message,dateadded,pos,status)values('"+nn.getid("application_form")+"','"+dropdown_applied_for.SelectedValue.ToString()+"','"+txt_name_exam_city.Text+"','"+txt_name_name.Text+"','"+txt_name_father_name.Text+"','"+txt_name_mother_name.Text+"','"+txt_name_dob.Text+"','"+dropdown_category.SelectedValue.ToString()+"','"+txt_name_mobile_number.Text+"','"+dropdown_blod_group.SelectedValue.ToString()+"','"+dropdown_physicaly_handicapped.SelectedValue.ToString()+"','"+dropdown_eye_sight.SelectedValue.ToString()+"','"+txt_name_email.Text+"','"+dropdown_gender.SelectedValue.ToString()+"','"+multi_txt_name_address.Text+"','"+txt_name_locality.Text+"','"+txt_name_city.Text+"','"+txt_name_pin_code.Text+"','"+txt_name_state.Text+"','"+txt_name_district.Text+"','"+txt_name_highschoolpassing_year.Text+"','"+txt_name_highschoolpercentage.Text+"','"+txt_name_intermediatepassing_year.Text+"','"+txt_name_intermediatepercentage.Text+"','"+txt_name_other_degree.Text+"','"+String_FileUpload_upload_photo+"','"+multi_txt_name_message.Text+"','"+DateTime.Now.ToString()+"','"+nn.getid("application_form")+"','true')");            }

  loaddata_MAIN_ADMIN();
   }
protected void update_Click(object sender, EventArgs e)
 {
 string id = update_MAIN_ADMIN.ToolTip.ToString();
 string String_FileUpload_upload_photo="";            Directory.CreateDirectory(Location2);
            if (FileUpload_upload_photo.HasFile)
            {
                FileUpload_upload_photo.SaveAs(Location2  + FileUpload_upload_photo.FileName.ToString());

                String_FileUpload_upload_photo = nn.Smallthumb(Location2, FileUpload_upload_photo.FileName, width, height);

                string filedel = Location2 + FileUpload_upload_photo.FileName.ToString();
                File.Delete(filedel);
 string UPDQRY = "update application_form set [exam_city]='" + txt_name_exam_city.Text + "',[name]='" + txt_name_name.Text + "',[father_name]='" + txt_name_father_name.Text + "',[mother_name]='" + txt_name_mother_name.Text + "',[dob]='" + txt_name_dob.Text + "',[mobile_number]='" + txt_name_mobile_number.Text + "',[email]='" + txt_name_email.Text + "',[address]='" + multi_txt_name_address.Text + "',[locality]='" + txt_name_locality.Text + "',[city]='" + txt_name_city.Text + "',[pin_code]='" + txt_name_pin_code.Text + "',[state]='" + txt_name_state.Text + "',[district]='" + txt_name_district.Text + "',[highschoolpassing_year]='" + txt_name_highschoolpassing_year.Text + "',[highschoolpercentage]='" + txt_name_highschoolpercentage.Text + "',[intermediatepassing_year]='" + txt_name_intermediatepassing_year.Text + "',[intermediatepercentage]='" + txt_name_intermediatepercentage.Text + "',[other_degree]='" + txt_name_other_degree.Text + "',[upload_photo]='" + String_FileUpload_upload_photo + "',[message]='" + multi_txt_name_message.Text + "' where id='" + id + "'";
nn.UpdateData(UPDQRY);            }
            else
            {
 string UPDQRY = "update application_form set [exam_city]='" + txt_name_exam_city.Text + "',[name]='" + txt_name_name.Text + "',[father_name]='" + txt_name_father_name.Text + "',[mother_name]='" + txt_name_mother_name.Text + "',[dob]='" + txt_name_dob.Text + "',[mobile_number]='" + txt_name_mobile_number.Text + "',[email]='" + txt_name_email.Text + "',[address]='" + multi_txt_name_address.Text + "',[locality]='" + txt_name_locality.Text + "',[city]='" + txt_name_city.Text + "',[pin_code]='" + txt_name_pin_code.Text + "',[state]='" + txt_name_state.Text + "',[district]='" + txt_name_district.Text + "',[highschoolpassing_year]='" + txt_name_highschoolpassing_year.Text + "',[highschoolpercentage]='" + txt_name_highschoolpercentage.Text + "',[intermediatepassing_year]='" + txt_name_intermediatepassing_year.Text + "',[intermediatepercentage]='" + txt_name_intermediatepercentage.Text + "',[other_degree]='" + txt_name_other_degree.Text + "',[message]='" + multi_txt_name_message.Text + "' where id='" + id + "'";
nn.UpdateData(UPDQRY);            }

loaddata_MAIN_ADMIN();
}
    }
