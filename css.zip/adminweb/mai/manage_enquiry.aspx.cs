using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Net;
    public partial class manage_enquiry : System.Web.UI.Page 
{
string Location2 = HttpContext.Current.Server.MapPath(" ")+"//temp//";


int width=200;


int height=200;


nitin nn = new nitin();

        protected void Page_Load(object sender, EventArgs e) {
if (!Page.IsPostBack) {
loaddata_MAIN_ADMIN();

 }
        }
   void loaddata_MAIN_ADMIN()
    {
 string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);


        SqlDataAdapter da = new SqlDataAdapter("select * from table_enquire order by id desc", sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);


        CollectionPager1.DataSource = ds.Tables[0].DefaultView;
        CollectionPager1.BindToControl = GRD1_MAIN_ADMIN;
        GRD1_MAIN_ADMIN.DataSource = CollectionPager1.DataSourcePaged;
    }
    protected void fixgrid_GRD1_MAIN_ADMIN(object sender, EventArgs e)
    {
        if (GRD1_MAIN_ADMIN.Rows.Count > 0)
        {
            //This replaces <td> with <th> and adds the scope attribute
            GRD1_MAIN_ADMIN.UseAccessibleHeader = true;

            //This will add the <thead> and <tbody> elements
            GRD1_MAIN_ADMIN.HeaderRow.TableSection = TableRowSection.TableHeader;


        }
    }
    protected void up_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("up", id, pos, "table_enquire");

        loaddata_MAIN_ADMIN();

    }

    protected void down_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("down", id, pos, "table_enquire");

        loaddata_MAIN_ADMIN();
    }


    protected void top_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.newtoppos(id, pos, "table_enquire");

        loaddata_MAIN_ADMIN();
    }


    protected void bot_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.bottompos(id, pos, "table_enquire");

        loaddata_MAIN_ADMIN();
    }

    protected void delete_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton delete = (LinkButton)sender;

        nitin mk = new nitin();

        mk.DeleteData("table_enquire", "id", delete.CommandArgument.ToString());

        loaddata_MAIN_ADMIN();

    }
    protected void delmulti_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();

        foreach (GridViewRow di in GRD1_MAIN_ADMIN.Rows)
        {
            HtmlInputCheckBox chk = (HtmlInputCheckBox)di.FindControl("check");
            HiddenField id = (HiddenField)di.FindControl("HiddenField1");

            if (chk.Checked)
            {
                nk.DeleteALL("delete table_enquire where id='" + id.Value.ToString() + "'");
            }

        }
        loaddata_MAIN_ADMIN();
    }

    protected void dellall_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();


        nk.DeleteALL("delete table_enquire");


        loaddata_MAIN_ADMIN();
    }
    protected void edit_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton ed = (LinkButton)sender;
        string ID = ed.CommandArgument.ToString();

        getdetails_MAIN_ADMIN(ID);

    }
    void getdetails_MAIN_ADMIN(string ID)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);

        try
        {
            string sql3 = "select * from table_enquire where id='" + ID + "'";
            SqlCommand sqlComm3 = new SqlCommand(sql3, sqlConn);
            sqlConn.Open();

            SqlDataReader dr3 = sqlComm3.ExecuteReader();
            if (dr3.Read())
            {
                update_MAIN_ADMIN.ToolTip = dr3[0].ToString();
                update_MAIN_ADMIN.Visible = true;
                insert_MAIN_ADMIN.Visible = false;
 txt_name_name.Text= dr3["name"].ToString();
txt_name_mobile.Text= dr3["mobile"].ToString();
txt_name_email.Text= dr3["email"].ToString();
txt_name_message.Text= dr3["message"].ToString();
   txt_name_enquiry_type.Text= dr3["enquiry_type"].ToString();
            }

            dr3.Close();
            sqlConn.Close();
        }
        finally
        {

            sqlConn.Close();
        }

    }
   protected void status(object sender, EventArgs e)
    {

        LinkButton ed = (LinkButton)sender;
        string id = ed.CommandArgument.ToString();
        string status = ed.ToolTip.ToString();


        nitin kj = new nitin();

        if (status == "False")
        {
           
            kj.UpdateData("update table_enquire set [status]='true' where id='" + id + "'");
        }
        else
        {
            kj.UpdateData("update table_enquire set [status]='false' where id='" + id + "'");
        }



      


        loaddata_MAIN_ADMIN();

    }

 protected void insert_Click(object sender, EventArgs e) {
 nn.InsertData("insert into table_enquire (id,name,mobile,email,message,dateadded,pos,status,enquiry_type)values('"+nn.getid("table_enquire")+"','"+txt_name_name.Text+"','"+txt_name_mobile.Text+"','"+txt_name_email.Text+"','"+txt_name_message.Text+"','"+DateTime.Now.ToString()+"','"+nn.getid("table_enquire")+"','true','"+txt_name_enquiry_type.Text+"')");
  loaddata_MAIN_ADMIN();
   }
protected void update_Click(object sender, EventArgs e)
 {
 string id = update_MAIN_ADMIN.ToolTip.ToString();
 string UPDQRY = "update table_enquire set [name]='" + txt_name_name.Text + "',[mobile]='" + txt_name_mobile.Text + "',[email]='" + txt_name_email.Text + "',[message]='" + txt_name_message.Text + "',[enquiry_type]='" + txt_name_enquiry_type.Text + "' where id='" + id + "'";
nn.UpdateData(UPDQRY);
loaddata_MAIN_ADMIN();
}
    }
