﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

public partial class admin_deleteimg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string tid = Request.QueryString["id"];

        string img = Request.QueryString["thumb"].ToString();

        string img1 = Request.QueryString["bigimg"].ToString();

        string img2 = Request.QueryString["oriimg"].ToString();

        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);


        string sql2 = "delete photos where id = '" + tid + "'";


        SqlCommand sqlComm2 = new SqlCommand(sql2, sqlConn);
        sqlConn.Open();
        sqlComm2.ExecuteNonQuery();
        sqlConn.Close();

        string loc = Server.MapPath(" ");
        string path = loc + "\\photo_album\\" + img;
        File.Delete(path);

        string loc1 = Server.MapPath(" ");
        string path1 = loc1 + "\\photo_album\\" + img1;
        File.Delete(path1);

        string loc2 = Server.MapPath(" ");
        string path2 = loc2 + "\\photo_album\\" + img2;
        File.Delete(path2);
     //   string loc = Server.MapPath(" ");
      //  string path = loc + "\\music_lib\\" + alb + "\\" + song;


       // File.Delete(path);
        string aid = Request.QueryString["aid"];

        Response.Redirect("editphotoalbum.aspx?id="+aid+"&num=5");


    }
}
