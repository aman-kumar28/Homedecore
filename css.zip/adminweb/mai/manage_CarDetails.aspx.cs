using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Net;
    public partial class manage_CarDetails : System.Web.UI.Page 
{
string Location2 = HttpContext.Current.Server.MapPath(" ")+"//temp//";


int width=200;


int height=200;


nitin nn = new nitin();
string table_name_7="";
string column_name_7="" ;
string table_name_8="";
string column_name_8="" ;
string table_name_9="";
string column_name_9="" ;

        protected void Page_Load(object sender, EventArgs e) {
if (!Page.IsPostBack) {
loaddata_MAIN_ADMIN();
nn.DROPDOWNBIND(dropdown_condition,"select * from "+table_name_7+"",""+column_name_7+"","id");
nn.DROPDOWNBIND(dropdown_fueltype,"select * from "+table_name_8+"",""+column_name_8+"","id");
nn.DROPDOWNBIND(dropdown_engine,"select * from "+table_name_9+"",""+column_name_9+"","id");

 }
        }
   void loaddata_MAIN_ADMIN()
    {
 string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);


        SqlDataAdapter da = new SqlDataAdapter("select * from table_car order by id desc", sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);


        CollectionPager1.DataSource = ds.Tables[0].DefaultView;
        CollectionPager1.BindToControl = GRD1_MAIN_ADMIN;
        GRD1_MAIN_ADMIN.DataSource = CollectionPager1.DataSourcePaged;
    }
    protected void fixgrid_GRD1_MAIN_ADMIN(object sender, EventArgs e)
    {
        if (GRD1_MAIN_ADMIN.Rows.Count > 0)
        {
            //This replaces <td> with <th> and adds the scope attribute
            GRD1_MAIN_ADMIN.UseAccessibleHeader = true;

            //This will add the <thead> and <tbody> elements
            GRD1_MAIN_ADMIN.HeaderRow.TableSection = TableRowSection.TableHeader;


        }
    }
    protected void up_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("up", id, pos, "table_car");

        loaddata_MAIN_ADMIN();

    }

    protected void down_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("down", id, pos, "table_car");

        loaddata_MAIN_ADMIN();
    }


    protected void top_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.newtoppos(id, pos, "table_car");

        loaddata_MAIN_ADMIN();
    }


    protected void bot_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.bottompos(id, pos, "table_car");

        loaddata_MAIN_ADMIN();
    }

    protected void delete_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton delete = (LinkButton)sender;

        nitin mk = new nitin();

        mk.DeleteData("table_car", "id", delete.CommandArgument.ToString());

        loaddata_MAIN_ADMIN();

    }
    protected void delmulti_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();

        foreach (GridViewRow di in GRD1_MAIN_ADMIN.Rows)
        {
            HtmlInputCheckBox chk = (HtmlInputCheckBox)di.FindControl("check");
            HiddenField id = (HiddenField)di.FindControl("HiddenField1");

            if (chk.Checked)
            {
                nk.DeleteALL("delete table_car where id='" + id.Value.ToString() + "'");
            }

        }
        loaddata_MAIN_ADMIN();
    }

    protected void dellall_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();


        nk.DeleteALL("delete table_car");


        loaddata_MAIN_ADMIN();
    }
    protected void edit_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton ed = (LinkButton)sender;
        string ID = ed.CommandArgument.ToString();

        getdetails_MAIN_ADMIN(ID);

    }
    void getdetails_MAIN_ADMIN(string ID)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);

        try
        {
            string sql3 = "select * from table_car where id='" + ID + "'";
            SqlCommand sqlComm3 = new SqlCommand(sql3, sqlConn);
            sqlConn.Open();

            SqlDataReader dr3 = sqlComm3.ExecuteReader();
            if (dr3.Read())
            {
                update_MAIN_ADMIN.ToolTip = dr3[0].ToString();
                update_MAIN_ADMIN.Visible = true;
                insert_MAIN_ADMIN.Visible = false;
 txt_name_name.Text= dr3["name"].ToString();
 txt_name_model.Text= dr3["model"].ToString();
txt_name_year.Text= dr3["year"].ToString();
txt_name_color.Text= dr3["color"].ToString();
   txt_name_mileage.Text= dr3["mileage"].ToString();
ckeditor_txt_name_other.Text= dr3["other"].ToString();
txt_name_text1.Text= dr3["text1"].ToString();
txt_name_text2.Text= dr3["text2"].ToString();
txt_name_text3.Text= dr3["text3"].ToString();
txt_name_text4.Text= dr3["text4"].ToString();
               }

            dr3.Close();
            sqlConn.Close();
        }
        finally
        {

            sqlConn.Close();
        }

    }
   protected void status(object sender, EventArgs e)
    {

        LinkButton ed = (LinkButton)sender;
        string id = ed.CommandArgument.ToString();
        string status = ed.ToolTip.ToString();


        nitin kj = new nitin();

        if (status == "False")
        {
           
            kj.UpdateData("update table_car set [status]='true' where id='" + id + "'");
        }
        else
        {
            kj.UpdateData("update table_car set [status]='false' where id='" + id + "'");
        }



      


        loaddata_MAIN_ADMIN();

    }

 protected void insert_Click(object sender, EventArgs e) {
 string String_FileUpload_image="";            Directory.CreateDirectory(Location2);
            if (FileUpload_image.HasFile)
            {
                FileUpload_image.SaveAs(Location2  + FileUpload_image.FileName.ToString());

                String_FileUpload_image = nn.Smallthumb(Location2, FileUpload_image.FileName, width, height);

                string filedel = Location2 + FileUpload_image.FileName.ToString();
                File.Delete(filedel);
 nn.InsertData("insert into table_car (id,name,image,model,year,color,condition,fueltype,engine,mileage,other,text1,text2,text3,text4,dateadded,pos,status)values('"+nn.getid("table_car")+"','"+txt_name_name.Text+"','"+String_FileUpload_image+"','"+txt_name_model.Text+"','"+txt_name_year.Text+"','"+txt_name_color.Text+"','"+dropdown_condition.SelectedValue.ToString()+"','"+dropdown_fueltype.SelectedValue.ToString()+"','"+dropdown_engine.SelectedValue.ToString()+"','"+txt_name_mileage.Text+"','" + Server.HtmlEncode(ckeditor_txt_name_other.Text) + "','"+txt_name_text1.Text+"','"+txt_name_text2.Text+"','"+txt_name_text3.Text+"','"+txt_name_text4.Text+"','"+DateTime.Now.ToString()+"','"+nn.getid("table_car")+"','true')");            }
            else
            {
 nn.InsertData("insert into table_car (id,name,image,model,year,color,condition,fueltype,engine,mileage,other,text1,text2,text3,text4,dateadded,pos,status)values('"+nn.getid("table_car")+"','"+txt_name_name.Text+"','"+String_FileUpload_image+"','"+txt_name_model.Text+"','"+txt_name_year.Text+"','"+txt_name_color.Text+"','"+dropdown_condition.SelectedValue.ToString()+"','"+dropdown_fueltype.SelectedValue.ToString()+"','"+dropdown_engine.SelectedValue.ToString()+"','"+txt_name_mileage.Text+"','" + Server.HtmlEncode(ckeditor_txt_name_other.Text) + "','"+txt_name_text1.Text+"','"+txt_name_text2.Text+"','"+txt_name_text3.Text+"','"+txt_name_text4.Text+"','"+DateTime.Now.ToString()+"','"+nn.getid("table_car")+"','true')");            }

  loaddata_MAIN_ADMIN();
   }
protected void update_Click(object sender, EventArgs e)
 {
 string id = update_MAIN_ADMIN.ToolTip.ToString();
 string String_FileUpload_image="";            Directory.CreateDirectory(Location2);
            if (FileUpload_image.HasFile)
            {
                FileUpload_image.SaveAs(Location2  + FileUpload_image.FileName.ToString());

                String_FileUpload_image = nn.Smallthumb(Location2, FileUpload_image.FileName, width, height);

                string filedel = Location2 + FileUpload_image.FileName.ToString();
                File.Delete(filedel);
 string UPDQRY = "update table_car set [name]='" + txt_name_name.Text + "',[image]='" + String_FileUpload_image + "',[model]='" + txt_name_model.Text + "',[year]='" + txt_name_year.Text + "',[color]='" + txt_name_color.Text + "',[mileage]='" + txt_name_mileage.Text + "',[other]='" + Server.HtmlEncode(ckeditor_txt_name_other.Text) + "',[text1]='" + txt_name_text1.Text + "',[text2]='" + txt_name_text2.Text + "',[text3]='" + txt_name_text3.Text + "',[text4]='" + txt_name_text4.Text + "' where id='" + id + "'";
nn.UpdateData(UPDQRY);            }
            else
            {
 string UPDQRY = "update table_car set [name]='" + txt_name_name.Text + "',[model]='" + txt_name_model.Text + "',[year]='" + txt_name_year.Text + "',[color]='" + txt_name_color.Text + "',[mileage]='" + txt_name_mileage.Text + "',[other]='" + Server.HtmlEncode(ckeditor_txt_name_other.Text) + "',[text1]='" + txt_name_text1.Text + "',[text2]='" + txt_name_text2.Text + "',[text3]='" + txt_name_text3.Text + "',[text4]='" + txt_name_text4.Text + "' where id='" + id + "'";
nn.UpdateData(UPDQRY);            }

loaddata_MAIN_ADMIN();
}
    }
