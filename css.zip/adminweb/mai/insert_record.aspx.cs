using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Net;
    public partial class insert_record : System.Web.UI.Page 
{
string Location2 = HttpContext.Current.Server.MapPath(" ")+"//temp//";


int width=200;


int height=200;


nitin nn = new nitin();

        protected void Page_Load(object sender, EventArgs e) {
if (!Page.IsPostBack) {
loaddata_MAIN_ADMIN();

 }
        }
   void loaddata_MAIN_ADMIN()
    {
 string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);


        SqlDataAdapter da = new SqlDataAdapter("select * from record order by id desc", sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);


        CollectionPager1.DataSource = ds.Tables[0].DefaultView;
        CollectionPager1.BindToControl = GRD1_MAIN_ADMIN;
        GRD1_MAIN_ADMIN.DataSource = CollectionPager1.DataSourcePaged;
    }
    protected void fixgrid_GRD1_MAIN_ADMIN(object sender, EventArgs e)
    {
        if (GRD1_MAIN_ADMIN.Rows.Count > 0)
        {
            //This replaces <td> with <th> and adds the scope attribute
            GRD1_MAIN_ADMIN.UseAccessibleHeader = true;

            //This will add the <thead> and <tbody> elements
            GRD1_MAIN_ADMIN.HeaderRow.TableSection = TableRowSection.TableHeader;


        }
    }
    protected void up_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("up", id, pos, "record");

        loaddata_MAIN_ADMIN();

    }

    protected void down_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.changepos("down", id, pos, "record");

        loaddata_MAIN_ADMIN();
    }


    protected void top_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.newtoppos(id, pos, "record");

        loaddata_MAIN_ADMIN();
    }


    protected void bot_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton i = (LinkButton)sender;

        string pos = i.CommandArgument.ToString();
        string id = i.ToolTip.ToString();

        nitin n = new nitin();
        n.bottompos(id, pos, "record");

        loaddata_MAIN_ADMIN();
    }

    protected void delete_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton delete = (LinkButton)sender;

        nitin mk = new nitin();

        mk.DeleteData("record", "id", delete.CommandArgument.ToString());

        loaddata_MAIN_ADMIN();

    }
    protected void delmulti_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();

        foreach (GridViewRow di in GRD1_MAIN_ADMIN.Rows)
        {
            HtmlInputCheckBox chk = (HtmlInputCheckBox)di.FindControl("check");
            HiddenField id = (HiddenField)di.FindControl("HiddenField1");

            if (chk.Checked)
            {
                nk.DeleteALL("delete record where id='" + id.Value.ToString() + "'");
            }

        }
        loaddata_MAIN_ADMIN();
    }

    protected void dellall_MAIN_ADMIN(object sender, EventArgs e)
    {
        nitin nk = new nitin();


        nk.DeleteALL("delete record");


        loaddata_MAIN_ADMIN();
    }
    protected void edit_MAIN_ADMIN(object sender, EventArgs e)
    {
        LinkButton ed = (LinkButton)sender;
        string ID = ed.CommandArgument.ToString();

        getdetails_MAIN_ADMIN(ID);

    }
    void getdetails_MAIN_ADMIN(string ID)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);

        try
        {
            string sql3 = "select * from record where id='" + ID + "'";
            SqlCommand sqlComm3 = new SqlCommand(sql3, sqlConn);
            sqlConn.Open();

            SqlDataReader dr3 = sqlComm3.ExecuteReader();
            if (dr3.Read())
            {
                update_MAIN_ADMIN.ToolTip = dr3[0].ToString();
                update_MAIN_ADMIN.Visible = true;
                insert_MAIN_ADMIN.Visible = false;
 txt_name_roll_no.Text= dr3["roll_no"].ToString();
txt_name_s_no.Text= dr3["s_no"].ToString();
txt_name_class.Text= dr3["class"].ToString();
txt_name_year.Text= dr3["year"].ToString();
txt_name_name.Text= dr3["name"].ToString();
txt_name_f_name.Text= dr3["f_name"].ToString();
txt_name_mother_name.Text= dr3["mother_name"].ToString();
txt_name_dob.Text= dr3["dob"].ToString();
txt_name_institute.Text= dr3["institute"].ToString();
txt_name_sub1.Text= dr3["sub1"].ToString();
txt_name_sub2.Text= dr3["sub2"].ToString();
txt_name_sub3.Text= dr3["sub3"].ToString();
txt_name_sub4.Text= dr3["sub4"].ToString();
txt_name_sub5.Text= dr3["sub5"].ToString();
txt_name_sub6.Text= dr3["sub6"].ToString();
txt_name_theory1.Text= dr3["theory1"].ToString();
txt_name_theory2.Text= dr3["theory2"].ToString();
txt_name_theory3.Text= dr3["theory3"].ToString();
txt_name_theory4.Text= dr3["theory4"].ToString();
txt_name_theory5.Text= dr3["theory5"].ToString();
txt_name_theory6.Text= dr3["theory6"].ToString();
txt_name_pratical1.Text= dr3["pratical1"].ToString();
txt_name_pratical2.Text= dr3["pratical2"].ToString();
txt_name_pratical3.Text= dr3["pratical3"].ToString();
txt_name_pratical4.Text= dr3["pratical4"].ToString();
txt_name_pratical5.Text= dr3["pratical5"].ToString();
txt_name_pratical6.Text= dr3["pratical6"].ToString();
               }

            dr3.Close();
            sqlConn.Close();
        }
        finally
        {

            sqlConn.Close();
        }

    }
   protected void status(object sender, EventArgs e)
    {

        LinkButton ed = (LinkButton)sender;
        string id = ed.CommandArgument.ToString();
        string status = ed.ToolTip.ToString();


        nitin kj = new nitin();

        if (status == "False")
        {
           
            kj.UpdateData("update record set [status]='true' where id='" + id + "'");
        }
        else
        {
            kj.UpdateData("update record set [status]='false' where id='" + id + "'");
        }



      


        loaddata_MAIN_ADMIN();

    }

 protected void insert_Click(object sender, EventArgs e) {
 nn.InsertData("insert into record (id,roll_no,s_no,class,year,name,f_name,mother_name,dob,institute,sub1,sub2,sub3,sub4,sub5,sub6,theory1,theory2,theory3,theory4,theory5,theory6,pratical1,pratical2,pratical3,pratical4,pratical5,pratical6,dateadded,pos,status)values('"+nn.getid("record")+"','"+txt_name_roll_no.Text+"','"+txt_name_s_no.Text+"','"+txt_name_class.Text+"','"+txt_name_year.Text+"','"+txt_name_name.Text+"','"+txt_name_f_name.Text+"','"+txt_name_mother_name.Text+"','"+txt_name_dob.Text+"','"+txt_name_institute.Text+"','"+txt_name_sub1.Text+"','"+txt_name_sub2.Text+"','"+txt_name_sub3.Text+"','"+txt_name_sub4.Text+"','"+txt_name_sub5.Text+"','"+txt_name_sub6.Text+"','"+txt_name_theory1.Text+"','"+txt_name_theory2.Text+"','"+txt_name_theory3.Text+"','"+txt_name_theory4.Text+"','"+txt_name_theory5.Text+"','"+txt_name_theory6.Text+"','"+txt_name_pratical1.Text+"','"+txt_name_pratical2.Text+"','"+txt_name_pratical3.Text+"','"+txt_name_pratical4.Text+"','"+txt_name_pratical5.Text+"','"+txt_name_pratical6.Text+"','"+DateTime.Now.ToString()+"','"+nn.getid("record")+"','true')");
  loaddata_MAIN_ADMIN();
   }
protected void update_Click(object sender, EventArgs e)
 {
 string id = update_MAIN_ADMIN.ToolTip.ToString();
 string UPDQRY = "update record set [roll_no]='" + txt_name_roll_no.Text + "',[s_no]='" + txt_name_s_no.Text + "',[class]='" + txt_name_class.Text + "',[year]='" + txt_name_year.Text + "',[name]='" + txt_name_name.Text + "',[f_name]='" + txt_name_f_name.Text + "',[mother_name]='" + txt_name_mother_name.Text + "',[dob]='" + txt_name_dob.Text + "',[institute]='" + txt_name_institute.Text + "',[sub1]='" + txt_name_sub1.Text + "',[sub2]='" + txt_name_sub2.Text + "',[sub3]='" + txt_name_sub3.Text + "',[sub4]='" + txt_name_sub4.Text + "',[sub5]='" + txt_name_sub5.Text + "',[sub6]='" + txt_name_sub6.Text + "',[theory1]='" + txt_name_theory1.Text + "',[theory2]='" + txt_name_theory2.Text + "',[theory3]='" + txt_name_theory3.Text + "',[theory4]='" + txt_name_theory4.Text + "',[theory5]='" + txt_name_theory5.Text + "',[theory6]='" + txt_name_theory6.Text + "',[pratical1]='" + txt_name_pratical1.Text + "',[pratical2]='" + txt_name_pratical2.Text + "',[pratical3]='" + txt_name_pratical3.Text + "',[pratical4]='" + txt_name_pratical4.Text + "',[pratical5]='" + txt_name_pratical5.Text + "',[pratical6]='" + txt_name_pratical6.Text + "' where id='" + id + "'";
nn.UpdateData(UPDQRY);
loaddata_MAIN_ADMIN();
}
    }
