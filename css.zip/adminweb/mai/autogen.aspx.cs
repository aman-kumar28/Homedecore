﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Data.SqlClient;

public partial class walladmin_autogen : System.Web.UI.Page
{
    int ddexixts = 0;
    int fileuploadexists = 0;
    string fileuploadid = "";
    public string gridviewitems = "";
    public string updatequery="";
    public string updatequery_without_images = "";
    public string status_matter = "";
    nitin nn = new nitin();
    void Page_Load(Object sender, EventArgs e)
    {
       

            if (!Page.IsPostBack)
            {
                try
                {
                    nn.DROPDOWNBIND(DropDownList1, "select * from sys.tables", "name", "name");
                }
                catch (Exception ex)
                {
                    Response.Write("Processor Usage" + ex.Message);
                }

                // nn.binddatagrid("select column_name from information_schema.columns where table_name='products'", MyDataGrid);

                // MyDataGrid.DataSource = data;
                // MyDataGrid.DataBind();
            }
        
      

    }

   public String Result = "";
   public string in_query = "";
   public string in_query2 = "";
   public string complete_inquery = "";
   public string updategetvalue = "";
    protected void GetValues_Click(Object sender, EventArgs e)
    {

        int i = 0;
        
        foreach (RepeaterItem dataGridItem in Repeater1.Items)
        {
            

            // get Values from Checkboxlist
            String Skills = "";
            foreach (ListItem item in ((CheckBoxList)dataGridItem.FindControl("CheckBoxList1")).Items)
            {
                HiddenField hide = (HiddenField)dataGridItem.FindControl("HiddenField1");

                if (item.Selected)
                {
                    i++;
                    Skills += "<div class=\"row form-group\"><div class=\"col-lg-12 has-success form-group\"><label class=\"control-label\" for=\"\">" + hide.Value.ToUpper().Replace("_", " ") + "</label>" + create_control(item.Value, hide.Value) + "</div></div>";
                    //Skills += "<tr>\n<td>\n<font color=\"red\" size=\"3pt\">" + hide.Value.ToUpper().Replace("_"," ") + "</font>\n</td>" + "\n<td>" + create_control(item.Value, hide.Value) + "\n</td>\n</tr>\n";
                   // nn.InsertData("insert into controls values('1','" + hide.Value + "','" + create_control_id(item.Value, hide.Value) + "')");
                    in_query = in_query + hide.Value+",";
                    in_query2 = in_query2 + create_control_id(item.Value, hide.Value,i)+",";
                    updategetvalue = updategetvalue + create_update_id(item.Value,hide.Value);
                }
            }

            
            Skills = Skills.TrimEnd(',');




            Result += Skills;


            String Skills2 = "";
            foreach (ListItem item in ((CheckBoxList)dataGridItem.FindControl("CheckBoxList2")).Items)
            {
                HiddenField hide = (HiddenField)dataGridItem.FindControl("HiddenField2");

                if (item.Selected)
                {
                    Skills2 = Skills2 + getgridviewbound(item.Value,hide.Value.ToString());
                }
            }
            gridviewitems = gridviewitems+ Skills2;
           
        }

            complete_inquery = "insert into " + DropDownList1.SelectedItem.Text + " (" + in_query.TrimEnd(',') + ")values(" + in_query2.TrimEnd(',') + ")";

            ResultField.Text = updategetvalue;


            string[] aspxLines = {"<%@ Page Language=\"C#\"  MasterPageFile=\"~/adminweb/MasterPage.master\" AutoEventWireup=\"true\"CodeFile=\""+txtpagename.Text.Trim()+".aspx.cs\" Inherits=\""+txtpagename.Text.Trim()+"\" %>",
"<%@ Register Assembly=\"CKEditor.NET\" Namespace=\"CKEditor.NET\" TagPrefix=\"CKEditor\" %>\n",
 "<%@ Register Assembly=\"CollectionPager\" Namespace=\"SiteUtils\" TagPrefix=\"cc1\" %>\n",
"<asp:Content ID=\"Content1\" ContentPlaceHolderID=\"head\" Runat=\"Server\">",
"</asp:Content>",
"<asp:Content ID=\"Content2\" ContentPlaceHolderID=\"ContentPlaceHolder1\" Runat=\"Server\">",

uppergridview()+gridviewitems+lowergridview(),
"  <cc1:CollectionPager ID=\"CollectionPager1\" runat=\"server\" BackNextDisplay=\"HyperLinks\" EnableViewState=\"False\" PageSize=\"10\" ResultsLocation=\"Top\"> </cc1:CollectionPager>	\n",


"<br/><table class=\"table table-striped m-b-none\" >",
Result,
"<tr><td>",
    "<asp:Button ID=\"insert_MAIN_ADMIN\" runat=\"server\" CssClass=\"templatemo-edit-btn\" BackColor=\"#428bca\" Height=\"40\" ForeColor=\"white\" Text=\"Submit\" onclick=\"insert_Click\" width=\"150px\"/>",
    "<asp:Button ID=\"update_MAIN_ADMIN\" runat=\"server\" Visible=\"false\" CssClass=\"templatemo-edit-btn\" BackColor=\"#428bca\" Height=\"40\" ForeColor=\"white\" Text=\"Update\" onclick=\"update_Click\" width=\"150px\"/>",
"</td><td>&nbsp;</td></tr>",
"</table>",
"</div>",
"</div>",
"</asp:Content>"};
                                 
        string[] csLines = {"using System;",
"using System.Collections;",
"using System.Configuration;",
"using System.Data;",
"using System.Linq;",
"using System.Web;",
"using System.Web.Security;",
"using System.Web.UI;",
"using System.Web.UI.HtmlControls;",
"using System.Web.UI.WebControls;",
"using System.Web.UI.WebControls.WebParts;",
"using System.Xml.Linq;",
"using System.Data.SqlClient;",
"using System.Drawing;",
"using System.Drawing.Imaging;",
"using System.Drawing.Drawing2D;",
"using System.IO;",
"using System.Text;",
"using System.Net;",
"    public partial class "+txtpagename.Text.Trim()+" : System.Web.UI.Page \n{",
"string Location2 = HttpContext.Current.Server.MapPath(\" \")+\"//temp//\";\n\n",
"int width=200;\n\n",
"int height=200;\n\n",
"nitin nn = new nitin();",
variables,
"        protected void Page_Load(object sender, EventArgs e) {",
  "if (!Page.IsPostBack) {",      
     "loaddata_MAIN_ADMIN();",
  ddl_query,
  " }",
"        }",
gridviewfullfuctioning(),

" protected void insert_Click(object sender, EventArgs e) {",
filecreate(),
"  loaddata_MAIN_ADMIN();",

 "   }",
 "protected void update_Click(object sender, EventArgs e)",
   " {",
     " string id = update_MAIN_ADMIN.ToolTip.ToString();",
     updatefilecreate(),

"loaddata_MAIN_ADMIN();",
    "}",


"    }"};
        File.WriteAllLines(Server.MapPath("" + txtpagename.Text.Trim() + ".aspx"), aspxLines);
        File.WriteAllLines(Server.MapPath("" + txtpagename.Text.Trim() + ".aspx.cs"), csLines);
        

        
    }
    //updatepanel

    string create_update_id(string itemid, string i)
    {
        string control_value = i;
        string ret_value = " ";
        if (itemid == "1")
        {

            ret_value = "txt_name_" + i + ".Text= dr3[\"" + control_value + "\"].ToString();\n";
            updatequery = updatequery + "[" + control_value + "]='\" + txt_name_" + i + ".Text + \"',";

            updatequery_without_images = updatequery_without_images + "[" + control_value + "]='\" + txt_name_" + i + ".Text + \"',";

        }
        else if (itemid == "2")
        {

           // ret_value = "dropdown_" + i + ".SelectedValue.ToString()= dr3[\"" + control_value + "\"].ToString();\n";

          
        }           
     
        else if (itemid == "8")
        {
            ret_value = "multi_txt_name_" + i + ".Text= dr3[\"" + control_value + "\"].ToString();\n";
            updatequery = updatequery + "[" + control_value + "]='\" + multi_txt_name_" + i + ".Text + \"',";
            updatequery_without_images = updatequery_without_images + "[" + control_value + "]='\" + multi_txt_name_" + i + ".Text + \"',";
            
        }
        else if (itemid == "9")
        {
            ret_value = "ckeditor_txt_name_" + i + ".Text= dr3[\"" + control_value + "\"].ToString();\n";
            updatequery = updatequery + "[" + control_value + "]='\" + Server.HtmlEncode(ckeditor_txt_name_" + i + ".Text) + \"',";
            updatequery_without_images = updatequery_without_images + "[" + control_value + "]='\" + Server.HtmlEncode(ckeditor_txt_name_" + i + ".Text) + \"',";
            
           
        }
        else if (itemid == "3")
        {
            updatequery = updatequery + "[" + control_value + "]='\" + String_FileUpload_" + i + " + \"',";

       

        }
        return ret_value;
    }
    
    //end
    //fileupload
    string filecreate()
    {
        string myString="";
        if (fileuploadexists != 0)
        {

            myString = " string " + fileuploadid + "=\"\";";
            myString = myString + "            Directory.CreateDirectory(Location2);\n";
            myString = myString + "            if ("+ fileuploadid.Replace("String_","")+".HasFile)\n";
            myString = myString + "            {\n";
            myString = myString + "                " + fileuploadid.Replace("String_", "") + ".SaveAs(Location2  + " + fileuploadid.Replace("String_", "") + ".FileName.ToString());\n";

            myString = myString + "\n";
            myString = myString + "                " + fileuploadid + " = nn.Smallthumb(Location2, " + fileuploadid.Replace("String_", "") + ".FileName, width, height);\n";
            myString = myString + "\n";
            myString = myString + "                string filedel = Location2 + " + fileuploadid.Replace("String_", "") + ".FileName.ToString();\n";
            myString = myString + "                File.Delete(filedel);\n";
            myString = myString + " nn.InsertData(" + "\"" + complete_inquery + "\"" + ");";

            myString = myString + "            }\n";
            myString = myString + "            else\n";
            myString = myString + "            {\n";
            myString = myString + " nn.InsertData(" + "\"" + complete_inquery + "\"" + ");";

            myString = myString + "            }\n";

        }
        else
        {
            myString = " nn.InsertData(" + "\"" + complete_inquery + "\"" + ");";
        }
      
        return myString;
    }
    string updatefilecreate()
    {
        string myString = "";
        if (fileuploadexists != 0)
        {

            myString = " string " + fileuploadid + "=\"\";";
            myString = myString + "            Directory.CreateDirectory(Location2);\n";
            myString = myString + "            if (" + fileuploadid.Replace("String_", "") + ".HasFile)\n";
            myString = myString + "            {\n";
            myString = myString + "                " + fileuploadid.Replace("String_", "") + ".SaveAs(Location2  + " + fileuploadid.Replace("String_", "") + ".FileName.ToString());\n";

            myString = myString + "\n";
            myString = myString + "                " + fileuploadid + " = nn.Smallthumb(Location2, " + fileuploadid.Replace("String_", "") + ".FileName, width, height);\n";
            myString = myString + "\n";
            myString = myString + "                string filedel = Location2 + " + fileuploadid.Replace("String_", "") + ".FileName.ToString();\n";
            myString = myString + "                File.Delete(filedel);\n";
            myString = myString + " string UPDQRY = \"update " + DropDownList1.SelectedItem.Text + " set " + updatequery.TrimEnd(',') + " where id='\" + id + \"'\";\n";
 myString = myString + "nn.UpdateData(UPDQRY);";

            myString = myString + "            }\n";
            myString = myString + "            else\n";
            myString = myString + "            {\n";
            myString = myString + " string UPDQRY = \"update " + DropDownList1.SelectedItem.Text + " set " + updatequery_without_images.TrimEnd(',') + " where id='\" + id + \"'\";\n";
            myString = myString + "nn.UpdateData(UPDQRY);";

            myString = myString + "            }\n";

        }
        else
        {
            myString = " string UPDQRY = \"update " + DropDownList1.SelectedItem.Text + " set " + updatequery_without_images.TrimEnd(',') + " where id='\" + id + \"'\";\n";
            myString = myString + "nn.UpdateData(UPDQRY);";
        }

        return myString;
    }
    //end 
    string create_control_id(string itemid, string i,int ide)
    {

        string ret_value = " ";
        if (itemid == "1")
        {
            ret_value = "'\"+txt_name_"+i+".Text+\"'";

        }
        else if (itemid == "2")
        {
            ret_value = "'\"+dropdown_" + i + ".SelectedValue.ToString()+\"'";

            variables = variables + "string table_name_"+ide+"=\"\";\nstring column_name_"+ide+"=\"\" ;\n";

            ddlfun("dropdown_" + i + "", "table_name_" + ide + "", "column_name_" + ide + "");
        }
        else if (itemid == "5")
        {
            ret_value = "'\"+nn.getid(\""+DropDownList1.SelectedItem.Text+"\")+\"'";

        }

        else if (itemid == "6")
        {
            ret_value = "'\"+nn.getid(\"" + DropDownList1.SelectedItem.Text + "\")+\"'";


        }
        else if (itemid == "7")
        {
            ret_value = "'\"+DateTime.Now.ToString()+\"'";
        }
        else if (itemid == "8")
        {
            ret_value = "'\"+multi_txt_name_" + i + ".Text+\"'";
        }
        else if (itemid == "9")
        {
            ret_value = "'\" + Server.HtmlEncode(ckeditor_txt_name_" + i + ".Text) + \"'";
        }
        else if (itemid == "10")
        {
            ret_value = "'true'";
        }
        else if (itemid == "3")
        {
            ret_value = "'\"+String_FileUpload_" + i + "+\"'";
           
            fileuploadid = fileuploadid + "String_FileUpload_" + i + "";

        }
        return ret_value;
    }
   
    string create_control(string itemid,string i)
    {
       
        string ret_value=" ";
        if (itemid == "1")
        {
            ret_value = "<asp:TextBox ID=\"txt_name_"+i+"\"  runat=\"server\" CssClass=\"form-control\"></asp:TextBox>\n";
          
        }
       else if (itemid == "2")
        {
            ret_value = "<asp:DropDownList ID=\"dropdown_"+i+"\" CssClass=\"form-control\" runat=\"server\"></asp:DropDownList>\n";

          
           // string INSRT = "insert into " + DropDownList1.SelectedItem.Text + " values('" + nn.getid(DropDownList1.SelectedItem.Text) + "','" + txt_name.Text + "','" + txt_keyword.Text + "','" + txt_meta_description.Text + "','" + txt_description.Text + "','true','" + DateTime.Now.ToString() + "','" + nn.getid(DropDownList1.SelectedItem.Text) + "')"; 
            ddexixts = 1;
        }
        else if (itemid == "3")
        {
            ret_value = "<asp:FileUpload ID=\"FileUpload_" + i + "\" CssClass=\"fa fa-cloud-upload text\" runat=\"server\" />\n";
            fileuploadexists = 1;
        }
        else if (itemid == "5")
        {
            string ret_value2 = "nn.getid(" + DropDownList1.SelectedItem.Text + ")";

        }

        else if (itemid == "6")
        {
            string ret_value2 = "nn.getid(" + DropDownList1.SelectedItem.Text + ")";


        }

        else if (itemid == "8")
        {
            ret_value = "<asp:TextBox ID=\"multi_txt_name_" + i + "\" TextMode=\"MultiLine\"  runat=\"server\" CssClass=\"form-control\" Rows=\"4\"></asp:TextBox>\n";


        }

        else if (itemid == "9")
        {
            ret_value = "  <CKEditor:CKEditorControl ID=\"ckeditor_txt_name_" + i + "\"  runat=\"server\"></CKEditor:CKEditorControl>\n";


        }
        return ret_value;
    }
  
    protected void Button1_Click(object sender, EventArgs e)
    {
        nn.repeaterdata("select column_name from information_schema.columns where table_name='"+DropDownList1.SelectedItem.Text+"'", Repeater1);
       
    
    }
   
    //dropdown create
    public string variables = "";
    public string ddl_query = "";
    string ddlfun(string ddl_id,string table_name,string col_name)
    {
        string retval = "";

        ddl_query = ddl_query + "nn.DROPDOWNBIND(" + ddl_id + ",\"select * from \"+" + table_name + "+\"\",\"\"+" + col_name + "+\"\",\"id\");\n";
        
        return retval;
    }
    //end
    //make gridview

    string uppergridview()
    {
        string myString = "<div class=\"col-xs-12\"> \n";
        myString = myString + "<div class=\"sec-box\"> \n";
        myString = myString + "<header><table><tr><td>";
        myString = myString + "<h2 class=\"heading\" style=\"text-transform:uppercase;\">" + DropDownList1.SelectedItem.Text.Replace("_", " ") + "</h2></td></tr> <tr><td></td></tr></table>\n</header>";
        myString = myString + " <asp:GridView ID=\"GRD1_MAIN_ADMIN\" runat=\"server\" \n";
        myString = myString + "           OnPreRender=\"fixgrid_GRD1_MAIN_ADMIN\" AutoGenerateColumns=\"False\" \n";
        myString = myString + "           EnableModelValidation=\"True\" CssClass=\"table table-striped m-b-none\" HeaderStyle-Height=\"35px\" HeaderStyle-ForeColor=\"White\" style=\"text-transform:uppercase;\" CellPadding=\"4\" GridLines=\"None\">\n";
        myString = myString + "            <AlternatingRowStyle BackColor=\"White\" />\n";
    
        myString = myString + "            <Columns>\n";
        myString = myString + "        <asp:TemplateField HeaderText=\"sel\">\n";
        myString = myString + "            <HeaderTemplate>\n";
        myString = myString + "                <input type=\"checkbox\" id=\"fcheckAll1\"  class=\"checkAll\" />\n";
        myString = myString + "            </HeaderTemplate>\n";
        myString = myString + "            <ItemTemplate>\n";
        myString = myString + "                <asp:HiddenField ID=\"HiddenField1\" Value='<%#Eval(\"id\") %>' runat=\"server\" />\n";
        myString = myString + "                <input  name='checkbox[]'  class='chkbox'  id=\"check\" type='checkbox'  runat=\"server\"    />\n";
        myString = myString + "            </ItemTemplate>  \n";
        
        
        myString = myString + "            </asp:TemplateField>\n";
        return myString;
    }

    string lowergridview()
    {
        string myString = "<asp:TemplateField HeaderText=\"&nbsp;&nbsp;Position\">\n";
myString = myString + "<ItemTemplate>\n";
myString = myString + "<asp:LinkButton ID=\"LinkButton1_MAIN_ADMIN\" CommandArgument='<%#Eval(\"pos\") %>' ToolTip='<%#Eval(\"id\") %>' OnClick=\"up_MAIN_ADMIN\" runat=\"server\" ForeColor=\"#13895f\" Font-Bold=\"true\">Up</asp:LinkButton>|\n";
myString = myString + "                                    <asp:LinkButton ID=\"LinkButton2zz_MAIN_ADMIN\" CommandArgument='<%#Eval(\"pos\") %>' ToolTip='<%#Eval(\"id\") %>' OnClick=\"down_MAIN_ADMIN\" runat=\"server\" ForeColor=\"#13895f\" Font-Bold=\"true\">Down</asp:LinkButton><br/>\n";
myString = myString + "                                    <asp:LinkButton ID=\"LinkButton3zz_MAIN_ADMIN\" OnClick=\"top_MAIN_ADMIN\" CommandArgument='<%#Eval(\"pos\") %>' ToolTip='<%#Eval(\"id\") %>' runat=\"server\" ForeColor=\"#13895f\" Font-Bold=\"true\">TOP</asp:LinkButton>|\n";
myString = myString + "                                    <asp:LinkButton ID=\"LinkButton4zz_MAIN_ADMIN\" OnClick=\"bot_MAIN_ADMIN\" CommandArgument='<%#Eval(\"pos\") %>' ToolTip='<%#Eval(\"id\") %>' runat=\"server\" ForeColor=\"#13895f\" Font-Bold=\"true\">Bottom</asp:LinkButton>\n";
myString = myString + "                                    \n";
myString = myString + "</ItemTemplate>\n";
myString = myString + "             <FooterStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
myString = myString + "             <HeaderStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
myString = myString + "             <ItemStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
myString = myString + "</asp:TemplateField>\n";
myString = myString + "<asp:TemplateField HeaderText=\"&nbsp;&nbsp;Action\">\n";
myString = myString + "               <ItemTemplate>\n";
myString = myString + "                <asp:LinkButton ID=\"LinkButton2x_MAIN_ADMIN\"  OnClick=\"edit_MAIN_ADMIN\" CommandArgument='<%#Eval(\"id\") %>'  runat=\"server\" CssClass=\"btn btn-success\" BackColor=\"#428bca\" BorderColor=\"White\">Edit</asp:LinkButton>&nbsp;<br /><br />";
myString = myString + "               </ItemTemplate>\n";
myString = myString + "                    <HeaderStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
myString = myString + "                    <ItemStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
myString = myString + "</asp:TemplateField>\n";
myString = myString + "<asp:TemplateField HeaderText=\"&nbsp;&nbsp;Action\">\n";
myString = myString + "               <ItemTemplate>\n";
myString = myString + "                   <asp:LinkButton ID=\"LinkButton1x_MAIN_ADMIN\" BackColor=\"#D9534F\" BorderColor=\"White\" OnClick=\"delete_MAIN_ADMIN\"  CommandArgument='<%#Eval(\"id\") %>' OnClientClick=\"if (!confirm('Are you sure you want delete?')) return false;\" runat=\"server\" CssClass=\"btn btn-success\">Delete</asp:LinkButton>\n";
myString = myString + "               </ItemTemplate>\n";
myString = myString + "                    <HeaderStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
myString = myString + "                    <ItemStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
myString = myString + "</asp:TemplateField>\n";

myString = myString + "  <asp:TemplateField HeaderText=\"&nbsp;&nbsp;Status\">\n";
myString = myString + "                <ItemTemplate>\n";
myString = myString + "                    <asp:LinkButton ID=\"LinkButton5\" CssClass=\"btn btn-success\" runat=\"server\" CausesValidation=\"false\" \n";
myString = myString + "                        CommandArgument='<%#Eval(\"id\") %>' \n";

myString = myString + "                        OnClick=\"status\" \n";
myString = myString + "                        Text='<%# Eval(\"status\").ToString().Equals(\"False\") ? \" Deactive \" : \" Active \" %>' \n";
myString = myString + "                        ToolTip='<%#Eval(\"status\") %>' BackColor=\"#3cb389\" BorderColor=\"#13895f\"></asp:LinkButton>\n";
myString = myString + "                </ItemTemplate>\n";
myString = myString + "            </asp:TemplateField>\n";
myString = myString + "            </Columns>\n";
myString = myString + "<EditRowStyle BackColor=\"#999999\" />\n";
myString = myString + "            <FooterStyle BackColor=\"#5D7B9D\" Font-Bold=\"True\" ForeColor=\"White\" />\n";
myString = myString + "\n";
myString = myString + "<HeaderStyle BackColor=\"#5D7B9D\" BorderColor=\"#DDDDDD\" ForeColor=\"White\" Height=\"35px\" \n";
myString = myString + "                Font-Bold=\"True\"></HeaderStyle>\n";
myString = myString + "            <PagerStyle BackColor=\"#284775\" ForeColor=\"White\" HorizontalAlign=\"Left\" />\n";
myString = myString + "            <RowStyle BackColor=\"#F7F6F3\" />\n";
myString = myString + "            <SelectedRowStyle BackColor=\"#E2DED6\" Font-Bold=\"True\" ForeColor=\"#333333\" />\n";
myString = myString + "            <SortedAscendingCellStyle BackColor=\"#E9E7E2\" />\n";
myString = myString + "            <SortedAscendingHeaderStyle BackColor=\"#506C8C\" />\n";
myString = myString + "            <SortedDescendingCellStyle BackColor=\"#FFFDF8\" />\n";
myString = myString + "            <SortedDescendingHeaderStyle BackColor=\"#6F8DAE\" />\n";
myString = myString + "        </asp:GridView>\n";
myString = myString + "   <div>\n";
myString = myString + "					   \n";
myString = myString + "					   <p></p>\n<br/>";
myString = myString + "					            <asp:LinkButton CssClass=\"templatemo-edit-btn\" ID=\"LinkButton1_MAIN_ADMIN\" OnClick=\"dellall_MAIN_ADMIN\" runat=\"server\">Delete All</asp:LinkButton>\n";
myString = myString + "                             \n";
myString = myString + "                               &nbsp;<asp:LinkButton CssClass=\"templatemo-edit-btn\" ID=\"LinkButton2_MAIN_ADMIN\" OnClick=\"delmulti_MAIN_ADMIN\" runat=\"server\">Delete Selected</asp:LinkButton>\n";
myString = myString + "                            \n";
myString = myString + "					   </div> \n<br/>";

        return myString;
    }

    string getgridviewbound(String item,string item_value)
    {
        string myString = "";
        if (item == "1")
        {
            myString = "<asp:BoundField DataField=\"" + item_value + "\" HeaderText=\"&nbsp;&nbsp;" + item_value + "\">\n";
            myString = myString + "             <FooterStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
            myString = myString + "             <HeaderStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
            myString = myString + "             <ItemStyle HorizontalAlign=\"Left\" VerticalAlign=\"Middle\" />\n";
            myString = myString + "             </asp:BoundField>\n";
        }
     
        return myString;
    }
    string gridviewfullfuctioning()
    {
      string  myString =  "   void loaddata_MAIN_ADMIN()\n";
        myString = myString + "    {\n";
        myString = myString + " string connectionString = ConfigurationManager.ConnectionStrings[\"LocalSqlServer\"].ConnectionString;\n";
        myString = myString + "        SqlConnection sqlConn = new SqlConnection(connectionString);\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "        SqlDataAdapter da = new SqlDataAdapter(\"select * from "+DropDownList1.SelectedItem.Text+" order by id desc\", sqlConn);\n";
        myString = myString + "        DataSet ds = new DataSet();\n";
        myString = myString + "        da.Fill(ds);\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "        CollectionPager1.DataSource = ds.Tables[0].DefaultView;\n";
        myString = myString + "        CollectionPager1.BindToControl = GRD1_MAIN_ADMIN;\n";
        myString = myString + "        GRD1_MAIN_ADMIN.DataSource = CollectionPager1.DataSourcePaged;\n";
        myString = myString + "    }\n";
        myString = myString + "    protected void fixgrid_GRD1_MAIN_ADMIN(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "        if (GRD1_MAIN_ADMIN.Rows.Count > 0)\n";
        myString = myString + "        {\n";
        myString = myString + "            //This replaces <td> with <th> and adds the scope attribute\n";
        myString = myString + "            GRD1_MAIN_ADMIN.UseAccessibleHeader = true;\n";
        myString = myString + "\n";
        myString = myString + "            //This will add the <thead> and <tbody> elements\n";
        myString = myString + "            GRD1_MAIN_ADMIN.HeaderRow.TableSection = TableRowSection.TableHeader;\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "        }\n";
        myString = myString + "    }\n";
        myString = myString + "    protected void up_MAIN_ADMIN(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "        LinkButton i = (LinkButton)sender;\n";
        myString = myString + "\n";
        myString = myString + "        string pos = i.CommandArgument.ToString();\n";
        myString = myString + "        string id = i.ToolTip.ToString();\n";
        myString = myString + "\n";
        myString = myString + "        nitin n = new nitin();\n";
        myString = myString + "        n.changepos(\"up\", id, pos, \"" + DropDownList1.SelectedItem.Text + "\");\n";
        myString = myString + "\n";
        myString = myString + "        loaddata_MAIN_ADMIN();\n";
        myString = myString + "\n";
        myString = myString + "    }\n";
        myString = myString + "\n";
        myString = myString + "    protected void down_MAIN_ADMIN(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "        LinkButton i = (LinkButton)sender;\n";
        myString = myString + "\n";
        myString = myString + "        string pos = i.CommandArgument.ToString();\n";
        myString = myString + "        string id = i.ToolTip.ToString();\n";
        myString = myString + "\n";
        myString = myString + "        nitin n = new nitin();\n";
        myString = myString + "        n.changepos(\"down\", id, pos, \"" + DropDownList1.SelectedItem.Text + "\");\n";
        myString = myString + "\n";
        myString = myString + "        loaddata_MAIN_ADMIN();\n";
        myString = myString + "    }\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "    protected void top_MAIN_ADMIN(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "        LinkButton i = (LinkButton)sender;\n";
        myString = myString + "\n";
        myString = myString + "        string pos = i.CommandArgument.ToString();\n";
        myString = myString + "        string id = i.ToolTip.ToString();\n";
        myString = myString + "\n";
        myString = myString + "        nitin n = new nitin();\n";
        myString = myString + "        n.newtoppos(id, pos, \"" + DropDownList1.SelectedItem.Text + "\");\n";
        myString = myString + "\n";
        myString = myString + "        loaddata_MAIN_ADMIN();\n";
        myString = myString + "    }\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "    protected void bot_MAIN_ADMIN(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "        LinkButton i = (LinkButton)sender;\n";
        myString = myString + "\n";
        myString = myString + "        string pos = i.CommandArgument.ToString();\n";
        myString = myString + "        string id = i.ToolTip.ToString();\n";
        myString = myString + "\n";
        myString = myString + "        nitin n = new nitin();\n";
        myString = myString + "        n.bottompos(id, pos, \"" + DropDownList1.SelectedItem.Text + "\");\n";
        myString = myString + "\n";
        myString = myString + "        loaddata_MAIN_ADMIN();\n";
        myString = myString + "    }\n";
        myString = myString + "\n";
        myString = myString + "    protected void delete_MAIN_ADMIN(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "        LinkButton delete = (LinkButton)sender;\n";
        myString = myString + "\n";
        myString = myString + "        nitin mk = new nitin();\n";
        myString = myString + "\n";
        myString = myString + "        mk.DeleteData(\"" + DropDownList1.SelectedItem.Text + "\", \"id\", delete.CommandArgument.ToString());\n";
        myString = myString + "\n";
        myString = myString + "        loaddata_MAIN_ADMIN();\n";
        myString = myString + "\n";
        myString = myString + "    }\n";
        myString = myString + "    protected void delmulti_MAIN_ADMIN(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "        nitin nk = new nitin();\n";
        myString = myString + "\n";
        myString = myString + "        foreach (GridViewRow di in GRD1_MAIN_ADMIN.Rows)\n";
        myString = myString + "        {\n";
        myString = myString + "            HtmlInputCheckBox chk = (HtmlInputCheckBox)di.FindControl(\"check\");\n";
        myString = myString + "            HiddenField id = (HiddenField)di.FindControl(\"HiddenField1\");\n";
        myString = myString + "\n";
        myString = myString + "            if (chk.Checked)\n";
        myString = myString + "            {\n";
        myString = myString + "                nk.DeleteALL(\"delete " + DropDownList1.SelectedItem.Text + " where id='\" + id.Value.ToString() + \"'\");\n";
        myString = myString + "            }\n";
        myString = myString + "\n";
        myString = myString + "        }\n";
        myString = myString + "        loaddata_MAIN_ADMIN();\n";
        myString = myString + "    }\n";
        myString = myString + "\n";
        myString = myString + "    protected void dellall_MAIN_ADMIN(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "        nitin nk = new nitin();\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "        nk.DeleteALL(\"delete " + DropDownList1.SelectedItem.Text + "\");\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "        loaddata_MAIN_ADMIN();\n";
        myString = myString + "    }\n";
        myString = myString + "    protected void edit_MAIN_ADMIN(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "        LinkButton ed = (LinkButton)sender;\n";
        myString = myString + "        string ID = ed.CommandArgument.ToString();\n";
        myString = myString + "\n";
        myString = myString + "        getdetails_MAIN_ADMIN(ID);\n";
        myString = myString + "\n";
        myString = myString + "    }\n";
        myString = myString + "    void getdetails_MAIN_ADMIN(string ID)\n";
        myString = myString + "    {\n";
        myString = myString + "        string connectionString = ConfigurationManager.ConnectionStrings[\"LocalSqlServer\"].ConnectionString;\n";
        myString = myString + "        SqlConnection sqlConn = new SqlConnection(connectionString);\n";
        myString = myString + "\n";
        myString = myString + "        try\n";
        myString = myString + "        {\n";
        myString = myString + "            string sql3 = \"select * from "+DropDownList1.SelectedItem.Text+" where id='\" + ID + \"'\";\n";
        myString = myString + "            SqlCommand sqlComm3 = new SqlCommand(sql3, sqlConn);\n";
        myString = myString + "            sqlConn.Open();\n";
        myString = myString + "\n";
        myString = myString + "            SqlDataReader dr3 = sqlComm3.ExecuteReader();\n";
        myString = myString + "            if (dr3.Read())\n";
        myString = myString + "            {\n";
        myString = myString + "                update_MAIN_ADMIN.ToolTip = dr3[0].ToString();\n";
        myString = myString + "                update_MAIN_ADMIN.Visible = true;\n";
        myString = myString + "                insert_MAIN_ADMIN.Visible = false;\n";
        myString = myString + updategetvalue;

        myString = myString + "            }\n";
        myString = myString + "\n";
        myString = myString + "            dr3.Close();\n";
        myString = myString + "            sqlConn.Close();\n";
        myString = myString + "        }\n";
        myString = myString + "        finally\n";
        myString = myString + "        {\n";
        myString = myString + "\n";
        myString = myString + "            sqlConn.Close();\n";
        myString = myString + "        }\n";
        myString = myString + "\n";
        myString = myString + "    }\n";
        myString = myString + "   protected void status(object sender, EventArgs e)\n";
        myString = myString + "    {\n";
        myString = myString + "\n";
        myString = myString + "        LinkButton ed = (LinkButton)sender;\n";
        myString = myString + "        string id = ed.CommandArgument.ToString();\n";
        myString = myString + "        string status = ed.ToolTip.ToString();\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "        nitin kj = new nitin();\n";
        myString = myString + "\n";
        myString = myString + "        if (status == \"False\")\n";
        myString = myString + "        {\n";
        myString = myString + "           \n";
        myString = myString + "            kj.UpdateData(\"update "+DropDownList1.SelectedItem.Text+" set [status]='true' where id='\" + id + \"'\");\n";
        myString = myString + "        }\n";
        myString = myString + "        else\n";
        myString = myString + "        {\n";
        myString = myString + "            kj.UpdateData(\"update " + DropDownList1.SelectedItem.Text + " set [status]='false' where id='\" + id + \"'\");\n";
        myString = myString + "        }\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "      \n";
        myString = myString + "\n";
        myString = myString + "\n";
        myString = myString + "        loaddata_MAIN_ADMIN();\n";
        myString = myString + "\n";
        myString = myString + "    }\n";

        return myString;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
       
      SqlConnection con = new SqlConnection
          (ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString);
        
        SqlCommand cmd = new SqlCommand(create_table_text.Text,con);
        try
	            {
	                con.Open();
	                cmd.ExecuteNonQuery();
	                Response.Write("<script>alert('Table Created')<script>");
	            }
	            catch (System.Exception ex)
	            {
                    Response.Write("<script>alert('Table Created failed')<script>");
                    ex.ToString();
	                
	            }
	            
	                    con.Close();
	                
	            }



}
