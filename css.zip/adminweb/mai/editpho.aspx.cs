﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class walladmin_adjustmp3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            // TextBox3.Text = "Type here";
            adjust();
           //chks();
        }
    }
    void adjust()
    {
        string id = Request.QueryString["id"].ToString();
        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;

        SqlConnection sqlConn = new SqlConnection(connectionString);

        string sql3 = "select * from photos where id='" + id + "'" + "ORDER BY date DESC";

        SqlCommand sqlComm3 = new SqlCommand(sql3, sqlConn);

        sqlConn.Open();

        SqlDataReader dr3 = sqlComm3.ExecuteReader();
        Repeater1.DataSource = dr3;
        Repeater1.DataBind();
        dr3.Close();
        sqlConn.Close();



    }


   protected void Button1_Click(object sender, EventArgs e)
    {

        foreach (RepeaterItem item in Repeater1.Items)
        {

            // find control of checkbox
            CheckBox chk = (CheckBox)item.FindControl("CheckBox1");



            
            TextBox titlt = (TextBox)item.FindControl("TextBox2");
            TextBox artist = (TextBox)item.FindControl("TextBox3");
            TextBox copy = (TextBox)item.FindControl("TextBox4");
            TextBox tags = (TextBox)item.FindControl("TextBox5");


          

            TextBox about = (TextBox)item.FindControl("TextBox2");

            if (chk.Checked == true)
            {
               // Response.Write(chk.ToolTip.ToString() + "<br>");

                   
           
                   

                    //


                string nes = chk.ToolTip.ToString();

                mukesh(nes, titlt.Text, artist.Text, copy.Text, tags.Text);
            }
        }
      

        string aid = Request.QueryString["aid"].ToString();


        Response.Redirect("editphotoalbum.aspx?id=" + aid);

    }

    void mukesh(string id,string titl,string artist,string cpy,string tag)
    {


      //  Response.Write(n);

        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);




        string sql2 = "update photos set Title='"+titl+"', Artist='"+artist+"' ,Copyrightnotice='"+cpy+"' ,tag='"+tag+"' where id=@id";


        SqlCommand sqlComm = new SqlCommand(sql2, sqlConn);

        sqlComm.Parameters.Add("@id", System.Data.SqlDbType.VarChar);
        sqlComm.Parameters["@id"].Value = id.ToString();

        
        sqlConn.Open();
        sqlComm.ExecuteNonQuery();
        sqlConn.Close();



    }

    //void chks()
    //{

    //    string id = Request.QueryString["id"].ToString();
    //    string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
    //    SqlConnection sqlConn = new SqlConnection(connectionString);

    //    string sql = "select * from mp3_album where id='" + id + "'";

    //    // Response.Write(sql);

    //    SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
    //    sqlConn.Open();
    //    SqlDataReader dr = sqlComm.ExecuteReader();
    //    if (dr.Read())
    //    {
    //        string n = dr[1].ToString();

    //        Label2.Text = "Album Name " + n;
    
    //    }
    //    else
    //    {



    //    }
    //    dr.Close();
    //    sqlConn.Close();

    //}
}
