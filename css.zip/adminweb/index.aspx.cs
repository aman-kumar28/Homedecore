﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class adminweb_login : System.Web.UI.Page
{
    AesCryp dc = new AesCryp();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (usrTxt.Text.Length < 3 || passTxt.Text.Length < 5)
        {
            Response.Write("Username or password is invalid or too short");
        }
        else
        {
            string directoryPath = Server.MapPath(string.Format("~/data/"));
            if (!Directory.Exists(directoryPath))
            {
                Response.Write(usrTxt + " was not found!");
            }
            else
            {
                string Location = Server.MapPath("") + "/data/data.txt";
                var sr = new StreamReader(Location);
                string encusr = sr.ReadLine();
                string encpass = sr.ReadLine();
                sr.Close();

                string decusr = dc.Decrypt(encusr);
                string decpass = dc.Decrypt(encpass);

                if (decusr == usrTxt.Text && decpass == passTxt.Text)
                {
                    Session["user"] = usrTxt.Text;
                    Response.Redirect("dashboard.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Error ! Username or Password is wrong');</script>");
                }
            }
        }
    }
}