﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


public partial class walladmin_sql_tool : System.Web.UI.Page
{
    void getpagelist()
    {
        int i = 100 / 10;
       
        for (int j=1; j <=i; j++)
        {
            Response.Write(j+"/");
        }
    }
    void getdataaccordingtopager(int value)
    {
        string start = ((value - 1).ToString() + (value - 1).ToString());
        string end = ((value).ToString() + (value - 1).ToString());
        Response.Write(end);
    }

    nitin nn = new nitin();
    void loadlist()
    {

        if (!Page.IsPostBack)
        {
                SqlDataSource2.SelectCommand = "select distinct query from sqlqueries";
                ListBox1.DataTextField = "query";
                ListBox1.DataBind();
                SqlDataSource3.SelectCommand = "select name  from sys.tables";
                ListBox3.DataTextField = "name";
                ListBox3.DataBind();
            
            
        }
    }
    void read()
    {
        string connection = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlconn = new SqlConnection(connection);

        string sql = "select name from sys.tables where name='sqlqueries'";

        SqlCommand sqlcomm = new SqlCommand(sql, sqlconn);
        sqlconn.Open();

        SqlDataReader dr = sqlcomm.ExecuteReader();
        if (dr.Read())
        {
            loadlist();

        }
        else
        {
            nn.InsertData(@"create table sqlqueries ( id int primary key identity(1,1), query varchar(max), dateadded datetime ) ");
        }
        dr.Close();
        sqlconn.Close();


    }

    protected void Page_Load(object sender, EventArgs e)
    {
        getpagelist();
        getdataaccordingtopager(2);
        read();
        string badString = "<div id=\"blink\" >About Us</div>";
        byte[] original = System.Text.Encoding.ASCII.GetBytes(badString);
        byte[] clean = (from b in original where b < 145 || b > 148 select b).ToArray<byte>();
        string cleanString = System.Text.Encoding.ASCII.GetString(clean);
        string cleanString2 = System.Text.Encoding.Unicode.GetString(clean);
        Response.Write(cleanString2);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlDataSource1.SelectCommand = txtsqlquery.Text;
            nn.InsertData("insert into sqlqueries values('"+txtsqlquery.Text+"','"+DateTime.Now.ToString()+"')");
        }
        catch (SqlException ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtsqlquery.Text = string.Empty;
        loadlist();
        txtsqlquery.Text = ListBox1.SelectedItem.Text.ToString();
    }

    protected void ListBox3_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtsqlquery.Text = string.Empty;
        loadlist();
        txtsqlquery.Text ="select * from " +ListBox3.SelectedItem.Text.ToString();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
       nn.DeleteALL("delete sqlqueries where query='"+ListBox1.SelectedItem.Text.ToString()+"'");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        

        SqlDataSource2.SelectCommand = "select distinct query from sqlqueries";
        ListBox1.DataTextField = "query";
        ListBox1.DataBind();
    }
}