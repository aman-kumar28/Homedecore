﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Net;



public partial class adminweb_index : System.Web.UI.Page
{
    SqlConnection connectionString = new SqlConnection(ConfigurationManager.ConnectionStrings["mvcconnection"].ConnectionString.ToString());
      teche nn = new teche();
    Int32 val;
    string Location2 = HttpContext.Current.Server.MapPath(" ");
    string links = "";
    int i = 1;
    protected void Page_Load(object sender, EventArgs e)
    {

      

        string url = Request.Url.ToString();
        string last = url.Substring(url.LastIndexOf('/') + 1);


        string[] files = Directory.GetFiles(Location2, "*.aspx");
        foreach (var item in files)
        {
            if ((i == 1) || (i == 5) || (i == 9))
            {

                links = links + "<a href=\"" + Request.Url.ToString().Replace(last, "") + item.ToString().Replace(Location2, "") + "\"><div class=\"col-xs-2\"><div class=\"stat-box colorfive\"><i class=\"chart\">&nbsp;</i><h3 style=\"margin-top:8px;text-transform: uppercase;color:white;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "").Replace("Manage", "").Replace("manage", "").Replace("Chenge", "change") + "</h3><h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Module</h4></div></div></a>";

                i++;

            }



            else
            {
                if (i % 2 == 0)
                {


                    links = links + "<a href=\"" + Request.Url.ToString().Replace(last, "") + item.ToString().Replace(Location2, "") + "\"><div class=\"col-xs-2\"><div class=\"stat-box colorone\"><i class=\"chart\">&nbsp;</i><h3 style=\"margin-top:8px;text-transform: uppercase;color:white;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "").Replace("Manage", "").Replace("manage", "") + "</h1><h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Module</h3></div></div></a>";
                    i++;
                }
                else
                {


                    links = links + "<a href=\"" + Request.Url.ToString().Replace(last, "") + item.ToString().Replace(Location2, "") + "\"><div class=\"col-xs-2\"><div class=\"stat-box colorsix\"><i class=\"chart\">&nbsp;</i><h3 style=\"margin-top:8px;text-transform: uppercase;color:white;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + item.ToString().Replace(Location2, "").Split('.').First().Replace("_", " ").Replace("\\", "").Replace("Manage", "").Replace("manage", "") + "</h1><h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Module</h3></div></div></a>";


                    i++;
                }
            }


        }
        lit_links.Text = links.Replace("autogen.aspx", "").Replace("autogen", "").Replace("adj.aspx", "").Replace("adj", "").Replace("ustimg.aspx", "").Replace("ustimg", "").Replace("deleteimg.aspx", "").Replace("deleteimg", "").Replace("editpho.aspx", "").Replace("editpho", "").Replace("toalbum.aspx", "").Replace("toalbum", "").Replace("sql_tool.aspx", "").Replace("sql tool", "");








        try
        {
            Label2.Text = Session["user"].ToString();


        }
        catch (Exception ex)
        {

        }
        if (Session["user"] == null)
        {
            //Response.Redirect("http://localhost:2350/Trenico/Logindex.aspx");






        }
        else
        {

        }

    }

    public string limit(string input)
    {

        string newstr = "";
        int l = input.Length;
        if (l > 10)
        {
            newstr = input.Substring(0, 20) + "...";

        }

        else
        {
            newstr = input;
        }
        return newstr;

    }
}