﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class clsRegistration
{
    public void SaveGDPI(string p, string p_2)
    {
        throw new NotImplementedException();
    }
}
