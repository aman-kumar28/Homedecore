﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


/// <summary>
/// Summary description for DatabaseManager
/// </summary>

public class DatabaseManager
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mvcconnection"].ToString());
    
    public bool ExecuteInsertUpdateDelete(string Query)
    {
        SqlCommand cmd = new SqlCommand(Query, con);
        if (ConnectionState.Closed == con.State)
            con.Open();
        int n = cmd.ExecuteNonQuery();
        con.Close();
        if (n > 0)
            return true;
        else
            return false;

    }
    public DataTable ExecuteSelect(string Query)
    {
        SqlDataAdapter da = new SqlDataAdapter(Query, con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }
}
