﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.NetworkInformation;

/// <summary>
/// Summary description for akil
/// </summary>
public class akil
{

 public string GetMacAddress()
    {
        NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
        string smacaddress = "";
        foreach (NetworkInterface adapter in nics)
        {
            if (smacaddress == "")
            {
                IPInterfaceProperties properties = adapter.GetIPProperties();
                smacaddress = adapter.GetPhysicalAddress().ToString();
            }
        }
        return smacaddress;
    }
}