﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Net;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net.Mail;
using System.Net;
/// <summary>
/// Summary description for nitin
/// </summary>
public class nitin
{

    public static string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;

    

    SqlConnection sqlConn = new SqlConnection(connectionString);
	public nitin()
	{

      
		//
		// TODO: Add constructor logic here
		//
	}

    


 public   void setheader(int i,Page p)
    {
        if (i == 0)
        {

            HtmlControl header = (HtmlControl)p.Master.FindControl("hd");
            header.Attributes.Add("class", "masthead2");
        }
        else
        {
            HtmlControl header = (HtmlControl)p.Master.FindControl("hd");

            HtmlControl bn = (HtmlControl)p.Master.FindControl("bn");
            HtmlControl sbn = (HtmlControl)p.Master.FindControl("sbn");
            HtmlControl bdy = (HtmlControl)p.Master.FindControl("bdy");
            sbn.Visible = true;
            bn.Visible = false;
            bdy.Attributes.Add("class", "subpage");
            header.Attributes.Add("class", "masthead2 smallhead");

        }

    }

 public void headertxt(string title,Page p)
 {

     Literal l = (Literal)p.Master.FindControl("ti");
    string  myString = "<div id=\"page-title\"><h1>"+title+"</h1></div>\n";

    l.Text = myString;

 }


    public void bind_gallery(string sql, ListView listview_id)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
        SqlConnection sqlConn = new SqlConnection(connectionString);

        string qry = sql;
        //  HttpContext.Current.Response.Write(qry);

        SqlDataAdapter da = new SqlDataAdapter(qry, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);

        listview_id.DataSource = ds.Tables[0].DefaultView;
        listview_id.DataBind();
    }



    public  string mailfromwebsite(string mailto,string msg,string subject)
    {
        try
        {
            string emaiserver = ConfigurationManager.AppSettings["mailserver"].ToString();
            string fromemail = ConfigurationManager.AppSettings["mailID"].ToString();
            string Emailpass = ConfigurationManager.AppSettings["mailpass"].ToString();


            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient(emaiserver);   //smtp.gmail.com for gmail
            mail.From = new MailAddress(fromemail,subject);
            mail.To.Add(mailto);
            mail.Subject = subject;

            string Body = msg;
            mail.Body = Body;
            mail.IsBodyHtml = true;
            SmtpServer.Port = 25;   //587 for gmail
            SmtpServer.Credentials = new System.Net.NetworkCredential(fromemail, Emailpass);
            SmtpServer.EnableSsl = false;
            SmtpServer.Send(mail);
            return "1";
        }
        catch (Exception j)
        {

            return "error " + j.ToString();

        }

    }


    string gen()
    {
        string d = System.Guid.NewGuid().ToString().Substring(0, 5);
        return d;
    }



    public Boolean DROPDOWNBIND(DropDownList DDLID, string SQLQUERY, string DDL_TEXT, string DDL_value)
    {
        try
        {




            DDLID.Items.Add(new ListItem("Select", "0"));
            DDLID.SelectedValue = "0";

            string sql = SQLQUERY;

            //Response.Write(sql);

            SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
            sqlConn.Open();
            SqlDataReader dr = sqlComm.ExecuteReader();
            while (dr.Read())
            {

                string catd = "";

                string username = dr[DDL_TEXT].ToString();
                int i = username.Length;
                //   Response.Write(i);
                if (i > 10)
                {
                    catd = username;
                }
                else
                {
                    catd = username;
                }

                DDLID.Items.Add(new ListItem("" + catd, dr[DDL_value].ToString()));


            }
            dr.Close();
            sqlConn.Close();
            return true;
        }

        catch (Exception ft)
        {

            return false;
        }
        finally
        {


            sqlConn.Close();

        }
    }





   public string Smallthumb(string location, string newname,int w,int h)
    {

        string sPhysicalPath = location;
        string sOrgFileName = newname;
        string ThumbNailName = "thumb_" + gen() + newname;
        System.Drawing.Image oImg = System.Drawing.Image.FromFile(sPhysicalPath + @"\" + sOrgFileName);
        System.Drawing.Image oThumbNail = new Bitmap(w, h, oImg.PixelFormat);
        Graphics oGraphic = Graphics.FromImage(oThumbNail);
        oGraphic.CompositingQuality = CompositingQuality.HighQuality;
        oGraphic.SmoothingMode = SmoothingMode.HighQuality;
        oGraphic.InterpolationMode = InterpolationMode.HighQualityBicubic;
        Rectangle oRectangle = new Rectangle(0, 0, w, h);
        oGraphic.DrawImage(oImg, oRectangle);
        oThumbNail.Save(sPhysicalPath + @"\" + ThumbNailName, ImageFormat.Jpeg);
        oImg.Dispose();

        return ThumbNailName;
    }

public void  resize_ratio(string fullpath, string ThumbNailName, string savepath, int width)
   {

       // image rezixe  strat

       System.Drawing.Image oImg = System.Drawing.Image.FromFile(fullpath);
       int wid = width;
       float he = oImg.PhysicalDimension.Height;
       float wi = oImg.PhysicalDimension.Width;
       float aspt = (float)he / (float)wi;
       int hei = (int)(wid * aspt);
       System.Drawing.Image oThumbNail = new Bitmap(wid, hei, oImg.PixelFormat);
       Graphics oGraphic = Graphics.FromImage(oThumbNail);
       oGraphic.CompositingQuality = CompositingQuality.HighQuality;
       oGraphic.SmoothingMode = SmoothingMode.HighQuality;
       oGraphic.InterpolationMode = InterpolationMode.HighQualityBicubic;

       Rectangle oRectangle = new Rectangle(0, 0, wid, hei);
       oGraphic.DrawImage(oImg, oRectangle);
       oThumbNail.Save(savepath + @"\" + ThumbNailName, ImageFormat.Jpeg);
       oImg.Dispose();
       ///end rezie
       ///

   }


public void resize_image(string fullpath, string ThumbNailName, string savepath, int width,int height)
{

    // image rezixe  strat

    System.Drawing.Image oImg = System.Drawing.Image.FromFile(fullpath);
    int wid = width;
    float he = oImg.PhysicalDimension.Height;
    float wi = oImg.PhysicalDimension.Width;
    float aspt = (float)he / (float)wi;
    int hei = height;
    System.Drawing.Image oThumbNail = new Bitmap(wid, hei, oImg.PixelFormat);
    Graphics oGraphic = Graphics.FromImage(oThumbNail);
    oGraphic.CompositingQuality = CompositingQuality.HighQuality;
    oGraphic.SmoothingMode = SmoothingMode.HighQuality;
    oGraphic.InterpolationMode = InterpolationMode.HighQualityBicubic;

    Rectangle oRectangle = new Rectangle(0, 0, wid, hei);
    oGraphic.DrawImage(oImg, oRectangle);
    oThumbNail.Save(savepath + @"\" + ThumbNailName, ImageFormat.Jpeg);
    oImg.Dispose();
    ///end rezie
    ///

}


public string return_collum(string SQL, string collumname)
{

    string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
    SqlConnection sqlConn = new SqlConnection(connectionString);

    try
    {


        SqlCommand sqlComm4 = new SqlCommand(SQL, sqlConn);
        sqlConn.Open();

        SqlDataReader dr4 = sqlComm4.ExecuteReader();

        if (dr4.Read())
        {


            string fl = dr4[collumname].ToString();
            dr4.Close();

            return fl;
        }
        else
        {
            dr4.Close();
            return "0";
        }

    }
    finally
    {

        sqlConn.Close();
    }
}

  public string mess(string mfrom,string sub,string bode,string mailto,string pass,FileUpload UploadControl)
   {
       try
       {

           //Response.Write("ddd");
           MailMessage mail = new MailMessage();
           // mail.To.Add(txtTo.Text);
           mail.To.Add(mfrom);
           mail.From = new MailAddress(mfrom);
           mail.Subject = sub;
           mail.Body = bode;
           mail.IsBodyHtml = true;

           //Attach file using FileUpload Control and put the file in memory stream



           if (UploadControl.HasFile)
           {
               mail.Attachments.Add(new Attachment(UploadControl.PostedFile.InputStream, UploadControl.FileName));
           }
           SmtpClient smtp = new SmtpClient();
           smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
           smtp.Credentials = new System.Net.NetworkCredential
                (mailto, pass);
           //Or your Smtp Email ID and Password
           smtp.EnableSsl = true;
           smtp.Send(mail);
       }
       catch (Exception dd)
       {

       }
       finally
       {
           
       }
       return null;
      

   }

  public Boolean repeaterdata(string query,Repeater name)
  {


      try
      {

          string sel = query;
          // Response.Write(sel);
          SqlCommand com = new SqlCommand(sel, sqlConn);

          sqlConn.Open();
          SqlDataReader dr = com.ExecuteReader();
          name.DataSource = dr;
          name.DataBind();

          dr.Close();
          return true;
      }
      catch (Exception dd)
      {
          return false;
      }

      finally
      {


          sqlConn.Close();
         
      }
      


  }

  public Boolean gridviewdata(string query, GridView name)
  {


      try
      {

          string sel = query;
          // Response.Write(sel);
          SqlCommand com = new SqlCommand(sel, sqlConn);

          sqlConn.Open();
          SqlDataReader dr = com.ExecuteReader();
          name.DataSource = dr;
          name.DataBind();

          dr.Close();
          return true;
      }
      catch (Exception dd)
      {
          return false;
      }

      finally
      {


          sqlConn.Close();

      }



  }



  public Boolean InsertData(string Values)
  {
      try
      {


          string sqlinn = Values;

          SqlCommand sqlComm = new SqlCommand(sqlinn, sqlConn);


          sqlConn.Open();
          sqlComm.ExecuteNonQuery();

          return true;

      }

      catch (Exception h)
      {
          return false;
      }
      finally
      {
          sqlConn.Close();
      }
  }
  

  public Boolean UpdateData(string Values)
  {

      try
      {
          string sql = Values;
          SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
          sqlConn.Open();
          sqlComm.ExecuteNonQuery();
          return true;
      }
      catch (Exception jk)
      {
          return false;
      }
      finally
      {
          sqlConn.Close();
      }

  }



  public Boolean DeleteALL(string Values)
  {
      try
      {

          string sql2 = Values;


          SqlCommand sqlComm2 = new SqlCommand(sql2, sqlConn);
          sqlConn.Open();

          sqlComm2.ExecuteNonQuery();
          return true;
      }
      catch (Exception jh)
      {
          return false;
      }
      finally
      {
          sqlConn.Close();
      }
  }

  public Boolean DeleteData(string table, string Condition, string value)
  {
      try
      {

          string sql2 = "delete " + table + " where " + Condition + "='" + value + "'";


          SqlCommand sqlComm2 = new SqlCommand(sql2, sqlConn);
          sqlConn.Open();

          sqlComm2.ExecuteNonQuery();
          return true;
      }
      catch (Exception jh)
      {
          return false;
      }
      finally
      {
          sqlConn.Close();
      }
  }

 

  public Int32 getid(string table)
  {
      string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
      SqlConnection sqlConn = new SqlConnection(connectionString);
      try
      {
          string sql = "SELECT MAX(id) AS id FROM " + table;

          SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
          sqlConn.Open();
          SqlDataReader dr = sqlComm.ExecuteReader();
          if (dr.Read())
          {
              if (dr[0] != DBNull.Value)
              {

                  string myid = dr[0].ToString();
                  int a = System.Convert.ToInt32(myid);
                  int b = a + 1;

                  return b;
              }
              else
              {

                  return 1;
              }
          }
          else
          {

              return 1;
              dr.Close();

          }
      }
      finally
      {


          sqlConn.Close();

      }

  }

 public Boolean changepos(string dir, string id, string pos,string table)
  {
      int j = Convert.ToInt32(pos);

      int i = 0;


      if (dir == "up")
      {


          i = j - 1;

      }
      else if (dir == "down")
      {

          i = j + 1;

      }




      //string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
      //SqlConnection sqlConn = new SqlConnection(connectionString);
      try
      {

          string sql = "SELECT * FROM " + table + " WHERE pos='" + i + "'";




          SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
          sqlConn.Open();
          SqlDataReader dr = sqlComm.ExecuteReader();
          if (dr.Read())
          {



              string id2 = dr["id"].ToString();

              nitin upd = new nitin();
              upd.UpdateData("update " + table + " set [pos]='" + pos + "' where id='" + id2 + "'");
              upd.UpdateData("update " + table + " set [pos]='" + i + "' where id='" + id + "'");
          }





          dr.Close();
          return true;
      }
      catch (Exception dd)
      {
          return false;
      }
      finally
      {
          sqlConn.Close();
      }


  }

 public Boolean toppos(string id, string pos,string table)
 {
     //swap
   try
     {

         string sql = "SELECT * FROM " + table + " WHERE pos ='" + pos + "'";
         SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
         sqlConn.Open();
         SqlDataReader dr = sqlComm.ExecuteReader();
         if (dr.Read())
         {

             string id2 = dr["id"].ToString();
             string pos2 = dr["pos"].ToString();
             //Response.Write(pos2);

             nitin upd = new nitin();

             string sql22 = "update " + table + " set pos='" + pos2 + "' where pos='1'";
             upd.UpdateData(sql22);

             string sql2 = "update " + table + " set pos='1' where id='" + id2 + "'";
             upd.UpdateData(sql2);
         }
         dr.Close();
         return true;
     }
     catch (Exception vv)
     {
         return false;
     }
     finally
     {
         sqlConn.Close();
     }


     // not working code
     //int j = Convert.ToInt32(pos);
     //try
     //{
     //    for (int i = 1; i < j; i++)
     //    {

     //            int g = i + 1;
     //            string sql = "SELECT * FROM " + table + " WHERE pos ='" + i + "'";
     //            SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
     //                sqlConn.Open();
     //                SqlDataReader dr = sqlComm.ExecuteReader();
     //                if (dr.Read())
     //                {
     //                    string id2 = dr["id"].ToString();

     //                    nitin upd = new nitin();

     //                    string sql22 = "update " + table + " set pos='" + g + "' where id='" + id2 + "'";
     //                    upd.UpdateData(sql22);
     //                }
     //                nitin upd2 = new nitin();

     //                string sql2 = "update " + table + " set pos='1' where id='" + id + "'";
     //                upd2.UpdateData(sql2);
     //                dr.Close();

     //                //return true;
     //    }


     //}
     //catch (Exception vv)
     //{
     //    //return false;
     //}
     //finally
     //{
     //    sqlConn.Close();
     //}


 }



 public void bottompos(string id, string pos,string table)
 {
     int k = Convert.ToInt32(pos);
     try
     {
     string sql = "SELECT MAX(pos) AS pos FROM " + table;
    
         SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
         sqlConn.Open();
         SqlDataReader dr = sqlComm.ExecuteReader();
         if (dr.Read())
         {
             string pos2 = dr["pos"].ToString();
             int j = Convert.ToInt32(pos2);
            
             for (int i = k; i <j; i++)
             {

                 
                 int g = i + 1;
                 nitin upd = new nitin();

                 string sql22 = "update " + table + " set pos='" + i + "' where pos='" + g + "'";
                 upd.UpdateData(sql22);

                


             }
             nitin upd2 = new nitin();

             string sql2 = "update " + table + " set pos='" + pos2 + "' where id='" + id + "'";
             upd2.UpdateData(sql2);

             dr.Close();
             
         }


     }
     catch (Exception n)
     {
        
     }
     finally
     {
         sqlConn.Close();
     }



     //string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
     //SqlConnection sqlConn = new SqlConnection(connectionString);
     //try
     //{
     //    string sql = "SELECT MAX(pos) AS pos FROM " + table;

     //    SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
     //    sqlConn.Open();
     //    SqlDataReader dr = sqlComm.ExecuteReader();
     //    if (dr.Read())
     //    {
     //        //string id2 = dr["id"].ToString();
     //        string pos2 = dr["pos"].ToString();
     //        //Response.Write(pos2);

     //        nitin upd = new nitin();

     //        string sql22 = "update " + table + " set pos='" + pos + "' where pos='" + pos2 + "'";
     //        upd.UpdateData(sql22);

     //        string sql2 = "update " + table + " set pos='" + pos2 + "' where id='" + id + "'";
     //        upd.UpdateData(sql2);



     //    }
     //    dr.Close();
     //    return true;
     //}

     //catch (Exception ff)
     //{
     //    return false;
     //}
     //finally
     //{


     //    sqlConn.Close();

     //}

 }

 public void newtoppos(string id, string pos, string table)
 {
     int j = Convert.ToInt32(pos);

     int i = 1;
     //string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
     //SqlConnection sqlConn = new SqlConnection(connectionString);
     for (i = 1; i < j; i++)
     {

         try
         {
             //Response.Write(i);
             string sql = "SELECT * FROM " + table + " WHERE pos ='" + j + "'";

             //Response.Write(sql);


             SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
             sqlConn.Open();
             SqlDataReader dr = sqlComm.ExecuteReader();
             if (dr.Read())
             {

                 string id2 = dr["id"].ToString();


                 nitin upd = new nitin();



                 string sql22 = "update " + table + " set pos='" + j + "' where pos='" + i + "'";
                 upd.UpdateData(sql22);

                 string sql2 = "update " + table + " set pos='" + i + "' where id='" + id2 + "'";
                 upd.UpdateData(sql2);



             }




             dr.Close();
             
         }
         catch (Exception vv)
         {
             
         }

         finally
         {


             sqlConn.Close();
         }
     }

 }


 public void newtoppo_side(string id, string pos, string table,string side)
 {
     int j = Convert.ToInt32(pos);

  

     int i = 1;
     //string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
     //SqlConnection sqlConn = new SqlConnection(connectionString);
     for (i = 1; i < j; i++)
     {

         try
         {
             //Response.Write(i);
             string sql = "SELECT * FROM " + table + " WHERE pos ='" + j + "' and side='"+side+"' ";

             //Response.Write(sql);


   

             SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
             sqlConn.Open();
             SqlDataReader dr = sqlComm.ExecuteReader();
             if (dr.Read())
             {

                 string id2 = dr["id"].ToString();


                 nitin upd = new nitin();



                 string sql22 = "update " + table + " set pos='" + j + "' where pos='" + i + "'  and side='" + side + "' ";
                 upd.UpdateData(sql22);

                 string sql2 = "update " + table + " set pos='" + i + "' where id='" + id2 + "'  and side='" + side + "' ";
                 upd.UpdateData(sql2);



             }




             dr.Close();

         }
         catch (Exception vv)
         {

         }

         finally
         {


             sqlConn.Close();
         }

         
     }

 }

 public void bottompos_side(string id, string pos, string table,string side)
 {
     int k = Convert.ToInt32(pos);
     try
     {
         string sql = "SELECT MAX(pos) AS pos FROM " + table + " where  side='" + side + "'";

         SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
         sqlConn.Open();
         SqlDataReader dr = sqlComm.ExecuteReader();
         if (dr.Read())
         {
             string pos2 = dr["pos"].ToString();
             int j = Convert.ToInt32(pos2);

             for (int i = k; i < j; i++)
             {


                 int g = i + 1;
                 nitin upd = new nitin();

                 string sql22 = "update " + table + " set pos='" + i + "' where pos='" + g + "' and side='" + side + "'";
                 upd.UpdateData(sql22);




             }
             nitin upd2 = new nitin();

             string sql2 = "update " + table + " set pos='" + pos2 + "' where id='" + id + "' and side='" + side + "'";
             upd2.UpdateData(sql2);

             dr.Close();

         }


     }
     catch (Exception n)
     {

     }
     finally
     {
         sqlConn.Close();
     }



     //string connectionString = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
     //SqlConnection sqlConn = new SqlConnection(connectionString);
     //try
     //{
     //    string sql = "SELECT MAX(pos) AS pos FROM " + table;

     //    SqlCommand sqlComm = new SqlCommand(sql, sqlConn);
     //    sqlConn.Open();
     //    SqlDataReader dr = sqlComm.ExecuteReader();
     //    if (dr.Read())
     //    {
     //        //string id2 = dr["id"].ToString();
     //        string pos2 = dr["pos"].ToString();
     //        //Response.Write(pos2);

     //        nitin upd = new nitin();

     //        string sql22 = "update " + table + " set pos='" + pos + "' where pos='" + pos2 + "'";
     //        upd.UpdateData(sql22);

     //        string sql2 = "update " + table + " set pos='" + pos2 + "' where id='" + id + "'";
     //        upd.UpdateData(sql2);



     //    }
     //    dr.Close();
     //    return true;
     //}

     //catch (Exception ff)
     //{
     //    return false;
     //}
     //finally
     //{


     //    sqlConn.Close();

     //}

 }




 public void insertIP(string SQL, string IP)
 {

     //  InsertData(SQL);

  
         string sqla = "select * from STATS_WEB where ip='" + IP + "'";

         SqlCommand sqlComm = new SqlCommand(sqla, sqlConn);
         sqlConn.Open();
         SqlDataReader dr = sqlComm.ExecuteReader();
         if (dr.Read())
         {

             string upd = "update STATS_WEB set [count]=[count]+1 where ip='" + IP + "'";

             UpdateData(upd);

         }
         else
         {
             InsertData(SQL);
         }
         dr.Close();

         sqlConn.Close();


 }



}
